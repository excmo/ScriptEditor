﻿namespace ScriptEd
{
    partial class addString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addString));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.abrirToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.guardarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.colorBt = new System.Windows.Forms.ToolStripDropDownButton();
            this.fr = new System.Windows.Forms.ToolStripMenuItem();
            this.black_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.white_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.gray_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.red_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.orange_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.green_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.lightgreen_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.blue_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.lightblue_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.lightblue2_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.cyan_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.lightblue3_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.navyblue_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.darknavyblue_fr = new System.Windows.Forms.ToolStripMenuItem();
            this.rs = new System.Windows.Forms.ToolStripMenuItem();
            this.em = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.playersNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rivalsNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.boxType = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.strId = new System.Windows.Forms.ToolStripTextBox();
            this.ayudaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btConv = new System.Windows.Forms.Button();
            this.btCl = new System.Windows.Forms.Button();
            this.btIns = new System.Windows.Forms.Button();
            this.stringBox = new System.Windows.Forms.RichTextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.stResult = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.prev = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.yesNo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gotoCall = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ynOffset = new System.Windows.Forms.TextBox();
            this.toolStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirToolStripButton,
            this.guardarToolStripButton,
            this.toolStripSeparator2,
            this.colorBt,
            this.toolStripButton3,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripSeparator3,
            this.boxType,
            this.toolStripSeparator,
            this.strId,
            this.ayudaToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(434, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // abrirToolStripButton
            // 
            this.abrirToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.abrirToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("abrirToolStripButton.Image")));
            this.abrirToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.abrirToolStripButton.Name = "abrirToolStripButton";
            this.abrirToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.abrirToolStripButton.Text = "&Abrir";
            // 
            // guardarToolStripButton
            // 
            this.guardarToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.guardarToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("guardarToolStripButton.Image")));
            this.guardarToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.guardarToolStripButton.Name = "guardarToolStripButton";
            this.guardarToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.guardarToolStripButton.Text = "&Guardar";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // colorBt
            // 
            this.colorBt.BackColor = System.Drawing.SystemColors.Control;
            this.colorBt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.colorBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.colorBt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fr,
            this.rs,
            this.em});
            this.colorBt.Image = global::ScriptEd.Properties.Resources.fontColor;
            this.colorBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(197)))), ((int)(((byte)(165)))));
            this.colorBt.Name = "colorBt";
            this.colorBt.Size = new System.Drawing.Size(29, 22);
            this.colorBt.Text = "Text color";
            // 
            // fr
            // 
            this.fr.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.black_fr,
            this.white_fr,
            this.gray_fr,
            this.red_fr,
            this.orange_fr,
            this.green_fr,
            this.lightgreen_fr,
            this.blue_fr,
            this.lightblue_fr,
            this.lightblue2_fr,
            this.cyan_fr,
            this.lightblue3_fr,
            this.navyblue_fr,
            this.darknavyblue_fr});
            this.fr.Name = "fr";
            this.fr.Size = new System.Drawing.Size(152, 22);
            this.fr.Text = "Firered colors";
            // 
            // black_fr
            // 
            this.black_fr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.black_fr.Image = global::ScriptEd.Properties.Resources.black;
            this.black_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.black_fr.Name = "black_fr";
            this.black_fr.Size = new System.Drawing.Size(154, 22);
            this.black_fr.Text = "Default";
            this.black_fr.Click += new System.EventHandler(this.doBlackFr);
            // 
            // white_fr
            // 
            this.white_fr.BackColor = System.Drawing.Color.Transparent;
            this.white_fr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.white_fr.Image = global::ScriptEd.Properties.Resources.white;
            this.white_fr.Name = "white_fr";
            this.white_fr.Size = new System.Drawing.Size(154, 22);
            this.white_fr.Text = "White";
            this.white_fr.Click += new System.EventHandler(this.doWhiteFr);
            // 
            // gray_fr
            // 
            this.gray_fr.BackColor = System.Drawing.Color.Transparent;
            this.gray_fr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gray_fr.Image = global::ScriptEd.Properties.Resources.gray;
            this.gray_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.gray_fr.Name = "gray_fr";
            this.gray_fr.Size = new System.Drawing.Size(154, 22);
            this.gray_fr.Text = "Gray";
            this.gray_fr.Click += new System.EventHandler(this.doGrayFr);
            // 
            // red_fr
            // 
            this.red_fr.BackColor = System.Drawing.Color.Transparent;
            this.red_fr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.red_fr.Image = global::ScriptEd.Properties.Resources.red;
            this.red_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.red_fr.Name = "red_fr";
            this.red_fr.Size = new System.Drawing.Size(154, 22);
            this.red_fr.Text = "Red (female)";
            this.red_fr.Click += new System.EventHandler(this.doRedFr);
            // 
            // orange_fr
            // 
            this.orange_fr.BackColor = System.Drawing.Color.Transparent;
            this.orange_fr.ForeColor = System.Drawing.SystemColors.ControlText;
            this.orange_fr.Image = global::ScriptEd.Properties.Resources.orange;
            this.orange_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.orange_fr.Name = "orange_fr";
            this.orange_fr.Size = new System.Drawing.Size(154, 22);
            this.orange_fr.Text = "Orange";
            this.orange_fr.Click += new System.EventHandler(this.doOrangeFr);
            // 
            // green_fr
            // 
            this.green_fr.Image = global::ScriptEd.Properties.Resources.green;
            this.green_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.green_fr.Name = "green_fr";
            this.green_fr.Size = new System.Drawing.Size(154, 22);
            this.green_fr.Text = "Green";
            this.green_fr.Click += new System.EventHandler(this.doGreenFr);
            // 
            // lightgreen_fr
            // 
            this.lightgreen_fr.Image = global::ScriptEd.Properties.Resources.light_green;
            this.lightgreen_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.lightgreen_fr.Name = "lightgreen_fr";
            this.lightgreen_fr.Size = new System.Drawing.Size(154, 22);
            this.lightgreen_fr.Text = "Light Green";
            this.lightgreen_fr.Click += new System.EventHandler(this.doLightGreenFr);
            // 
            // blue_fr
            // 
            this.blue_fr.Image = global::ScriptEd.Properties.Resources.blue;
            this.blue_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.blue_fr.Name = "blue_fr";
            this.blue_fr.Size = new System.Drawing.Size(154, 22);
            this.blue_fr.Text = "Blue (male)";
            this.blue_fr.Click += new System.EventHandler(this.doBlueFr);
            // 
            // lightblue_fr
            // 
            this.lightblue_fr.Image = global::ScriptEd.Properties.Resources.light_blue;
            this.lightblue_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.lightblue_fr.Name = "lightblue_fr";
            this.lightblue_fr.Size = new System.Drawing.Size(154, 22);
            this.lightblue_fr.Text = "Light Blue";
            this.lightblue_fr.Click += new System.EventHandler(this.doLightBlueFr);
            // 
            // lightblue2_fr
            // 
            this.lightblue2_fr.Image = global::ScriptEd.Properties.Resources.light_blue2;
            this.lightblue2_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.lightblue2_fr.Name = "lightblue2_fr";
            this.lightblue2_fr.Size = new System.Drawing.Size(154, 22);
            this.lightblue2_fr.Text = "Light Blue 2";
            this.lightblue2_fr.Click += new System.EventHandler(this.doLightBlue2Fr);
            // 
            // cyan_fr
            // 
            this.cyan_fr.Image = global::ScriptEd.Properties.Resources.cyan;
            this.cyan_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.cyan_fr.Name = "cyan_fr";
            this.cyan_fr.Size = new System.Drawing.Size(154, 22);
            this.cyan_fr.Text = "Cyan";
            this.cyan_fr.Click += new System.EventHandler(this.doCyanFr);
            // 
            // lightblue3_fr
            // 
            this.lightblue3_fr.Image = global::ScriptEd.Properties.Resources.light_blue3;
            this.lightblue3_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.lightblue3_fr.Name = "lightblue3_fr";
            this.lightblue3_fr.Size = new System.Drawing.Size(154, 22);
            this.lightblue3_fr.Text = "Light Blue 3";
            this.lightblue3_fr.Click += new System.EventHandler(this.doLightBlue3Fr);
            // 
            // navyblue_fr
            // 
            this.navyblue_fr.Image = global::ScriptEd.Properties.Resources.navy_blue;
            this.navyblue_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.navyblue_fr.Name = "navyblue_fr";
            this.navyblue_fr.Size = new System.Drawing.Size(154, 22);
            this.navyblue_fr.Text = "Navy Blue";
            this.navyblue_fr.Click += new System.EventHandler(this.doNavyBlueFr);
            // 
            // darknavyblue_fr
            // 
            this.darknavyblue_fr.Image = global::ScriptEd.Properties.Resources.dark_navy_blue;
            this.darknavyblue_fr.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.darknavyblue_fr.Name = "darknavyblue_fr";
            this.darknavyblue_fr.Size = new System.Drawing.Size(154, 22);
            this.darknavyblue_fr.Text = "Dark Navy Blue";
            this.darknavyblue_fr.Click += new System.EventHandler(this.doDarkNavyBlueFr);
            // 
            // rs
            // 
            this.rs.Name = "rs";
            this.rs.Size = new System.Drawing.Size(152, 22);
            this.rs.Text = "Ruby colors";
            // 
            // em
            // 
            this.em.Name = "em";
            this.em.Size = new System.Drawing.Size(152, 22);
            this.em.Text = "Emerald colors";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playersNameToolStripMenuItem,
            this.rivalsNameToolStripMenuItem,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.toolStripButton3.Image = global::ScriptEd.Properties.Resources.specialChar;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton3.Text = "Special codes";
            // 
            // playersNameToolStripMenuItem
            // 
            this.playersNameToolStripMenuItem.Name = "playersNameToolStripMenuItem";
            this.playersNameToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.playersNameToolStripMenuItem.Text = "Player\'s name";
            // 
            // rivalsNameToolStripMenuItem
            // 
            this.rivalsNameToolStripMenuItem.Name = "rivalsNameToolStripMenuItem";
            this.rivalsNameToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.rivalsNameToolStripMenuItem.Text = "Rival\'s name";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(147, 22);
            this.toolStripMenuItem2.Text = "...";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(147, 22);
            this.toolStripMenuItem3.Text = "$";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(147, 22);
            this.toolStripMenuItem4.Text = "♀";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(147, 22);
            this.toolStripMenuItem5.Text = "♂";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::ScriptEd.Properties.Resources.newLine;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "New box";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::ScriptEd.Properties.Resources.newBox;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "New line";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // boxType
            // 
            this.boxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boxType.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.boxType.Items.AddRange(new object[] {
            "Given item (0x0)",
            "Found item (0x1)",
            "Auto face (0x2)",
            "Signpost (0x3)",
            "Keep open (0x4)",
            "Yes / no (0x5)",
            "Normal (0x6)",
            "Nav call (0xA)"});
            this.boxType.MaxDropDownItems = 9;
            this.boxType.Name = "boxType";
            this.boxType.Size = new System.Drawing.Size(120, 25);
            this.boxType.SelectedIndexChanged += new System.EventHandler(this.enableYN);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // strId
            // 
            this.strId.Name = "strId";
            this.strId.Size = new System.Drawing.Size(80, 25);
            this.strId.Text = "stringName";
            // 
            // ayudaToolStripButton
            // 
            this.ayudaToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ayudaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ayudaToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("ayudaToolStripButton.Image")));
            this.ayudaToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ayudaToolStripButton.Name = "ayudaToolStripButton";
            this.ayudaToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.ayudaToolStripButton.Text = "Ay&uda";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.stringBox, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 25);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(434, 336);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.btConv, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btCl, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.btIns, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 299);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(428, 34);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // btConv
            // 
            this.btConv.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btConv.Location = new System.Drawing.Point(33, 5);
            this.btConv.Name = "btConv";
            this.btConv.Size = new System.Drawing.Size(75, 23);
            this.btConv.TabIndex = 2;
            this.btConv.Text = "Convert";
            this.btConv.UseVisualStyleBackColor = true;
            this.btConv.Click += new System.EventHandler(this.convertText);
            // 
            // btCl
            // 
            this.btCl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btCl.Location = new System.Drawing.Point(318, 5);
            this.btCl.Name = "btCl";
            this.btCl.Size = new System.Drawing.Size(75, 23);
            this.btCl.TabIndex = 1;
            this.btCl.Text = "Cancel";
            this.btCl.UseVisualStyleBackColor = true;
            // 
            // btIns
            // 
            this.btIns.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btIns.Location = new System.Drawing.Point(175, 5);
            this.btIns.Name = "btIns";
            this.btIns.Size = new System.Drawing.Size(75, 23);
            this.btIns.TabIndex = 0;
            this.btIns.Text = "Insert";
            this.btIns.UseVisualStyleBackColor = true;
            this.btIns.Click += new System.EventHandler(this.setString);
            // 
            // stringBox
            // 
            this.stringBox.DetectUrls = false;
            this.stringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stringBox.EnableAutoDragDrop = true;
            this.stringBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stringBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(96)))), ((int)(((byte)(96)))));
            this.stringBox.Location = new System.Drawing.Point(3, 3);
            this.stringBox.Name = "stringBox";
            this.stringBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.stringBox.Size = new System.Drawing.Size(428, 200);
            this.stringBox.TabIndex = 0;
            this.stringBox.Text = "";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 209);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(428, 84);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.stResult);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(420, 58);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Converted text";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // stResult
            // 
            this.stResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stResult.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stResult.Location = new System.Drawing.Point(3, 3);
            this.stResult.Multiline = true;
            this.stResult.Name = "stResult";
            this.stResult.ReadOnly = true;
            this.stResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.stResult.Size = new System.Drawing.Size(414, 52);
            this.stResult.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(420, 58);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Box preview";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel2.BackgroundImage = global::ScriptEd.Properties.Resources.textbox2;
            this.tableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.prev, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(77, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(240, 50);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // prev
            // 
            this.prev.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.prev.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.prev.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.prev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.prev.Location = new System.Drawing.Point(16, 12);
            this.prev.Name = "prev";
            this.prev.ReadOnly = true;
            this.prev.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.prev.Size = new System.Drawing.Size(208, 26);
            this.prev.TabIndex = 1;
            this.prev.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.flowLayoutPanel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(420, 58);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Yes / No options";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.yesNo);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.gotoCall);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.ynOffset);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(414, 52);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "If";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // yesNo
            // 
            this.yesNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.yesNo.FormattingEnabled = true;
            this.yesNo.Items.AddRange(new object[] {
            "no",
            "yes"});
            this.yesNo.Location = new System.Drawing.Point(22, 3);
            this.yesNo.Name = "yesNo";
            this.yesNo.Size = new System.Drawing.Size(45, 21);
            this.yesNo.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(73, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "was selected, then";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // gotoCall
            // 
            this.gotoCall.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gotoCall.FormattingEnabled = true;
            this.gotoCall.Items.AddRange(new object[] {
            "go to",
            "call"});
            this.gotoCall.Location = new System.Drawing.Point(175, 3);
            this.gotoCall.Name = "gotoCall";
            this.gotoCall.Size = new System.Drawing.Size(50, 21);
            this.gotoCall.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(231, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "offset #";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // ynOffset
            // 
            this.ynOffset.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ynOffset.Location = new System.Drawing.Point(280, 3);
            this.ynOffset.MaxLength = 6;
            this.ynOffset.Name = "ynOffset";
            this.ynOffset.Size = new System.Drawing.Size(60, 20);
            this.ynOffset.TabIndex = 5;
            this.ynOffset.Text = "000000";
            // 
            // addString
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btCl;
            this.ClientSize = new System.Drawing.Size(434, 361);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "addString";
            this.ShowInTaskbar = false;
            this.Text = "Add string";
            this.Load += new System.EventHandler(this.initString);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton abrirToolStripButton;
        private System.Windows.Forms.ToolStripButton guardarToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.RichTextBox stringBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btConv;
        private System.Windows.Forms.Button btCl;
        private System.Windows.Forms.Button btIns;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.RichTextBox prev;
        private System.Windows.Forms.TextBox stResult;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripComboBox boxType;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton3;
        private System.Windows.Forms.ToolStripTextBox strId;
        private System.Windows.Forms.ToolStripButton ayudaToolStripButton;
        private System.Windows.Forms.ToolStripMenuItem playersNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rivalsNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton colorBt;
        private System.Windows.Forms.ToolStripMenuItem fr;
        private System.Windows.Forms.ToolStripMenuItem black_fr;
        private System.Windows.Forms.ToolStripMenuItem white_fr;
        private System.Windows.Forms.ToolStripMenuItem gray_fr;
        private System.Windows.Forms.ToolStripMenuItem red_fr;
        private System.Windows.Forms.ToolStripMenuItem orange_fr;
        private System.Windows.Forms.ToolStripMenuItem green_fr;
        private System.Windows.Forms.ToolStripMenuItem lightgreen_fr;
        private System.Windows.Forms.ToolStripMenuItem blue_fr;
        private System.Windows.Forms.ToolStripMenuItem lightblue_fr;
        private System.Windows.Forms.ToolStripMenuItem lightblue2_fr;
        private System.Windows.Forms.ToolStripMenuItem cyan_fr;
        private System.Windows.Forms.ToolStripMenuItem lightblue3_fr;
        private System.Windows.Forms.ToolStripMenuItem navyblue_fr;
        private System.Windows.Forms.ToolStripMenuItem darknavyblue_fr;
        private System.Windows.Forms.ToolStripMenuItem rs;
        private System.Windows.Forms.ToolStripMenuItem em;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox yesNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox gotoCall;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ynOffset;
    }
}