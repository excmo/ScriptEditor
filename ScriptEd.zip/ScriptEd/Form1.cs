﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScriptEd
{
    public partial class mainWindow : Form
    {
        Conversors convert = new Conversors();
        public mainWindow()
        {
            InitializeComponent();
        }

        private void openStringFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openFirst(object sender, EventArgs e)
        {
            startDialog start = new startDialog();
            start.ShowDialog();
            if(ScriptEd.Program.romType==0)
            {
                romTypeText.Text = "Ruby";
                romTypeText.ForeColor = Color.DarkRed;
            }
            if (ScriptEd.Program.romType == 1)
            {
                romTypeText.Text = "FireRed";
                romTypeText.ForeColor = Color.OrangeRed;
            }
            if (ScriptEd.Program.romType == 2)
            {
                romTypeText.Text = "Emerald";
                romTypeText.ForeColor = Color.DarkGreen;
            }
            if(ScriptEd.Program.offType==0)
            {
                scriptBox.Text = "#dynamic 0x" + ScriptEd.Program.dynamicOffset;
                scriptBox.Text = scriptBox.Text + System.Environment.NewLine + "'--------------" + System.Environment.NewLine + "#org @"+ ScriptEd.Program.currentScriptId + System.Environment.NewLine;
            }
            else
            {
                scriptBox.Text = "#org 0x" + ScriptEd.Program.fixedOffset;
                scriptBox.Text = scriptBox.Text + System.Environment.NewLine;
            }
        }

        private void hexToDec(object sender, EventArgs e)
        {
            int dec;
            dec=convert.hexToDec(HTD.Text);
            DTH.Text = string.Concat(dec);
        }

        private void decToHex(object sender, EventArgs e)
        {
            try
            {
                int dec = int.Parse(DTH.Text);
                HTD.Text = convert.decToHex(dec);
            }
            catch (Exception)
            {
                DialogResult result = MessageBox.Show("Only possitive integers are allowed in this box (0-9).", "Wrong input", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                HTD.Text = "";
                DTH.Text = "";
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void advPic_Click(object sender, EventArgs e)
        {
            pokepicPos adv = new pokepicPos();
            ScriptEd.Program.pokepic_x = (int)pokepicX.Value;
            ScriptEd.Program.pokepic_y = (int)pokepicY.Value;
            adv.ShowDialog();
            pokepicX.Value = ScriptEd.Program.pokepic_x;
            pokepicY.Value = ScriptEd.Program.pokepic_y;
            ScriptEd.Program.pokepic_x = 10;
            ScriptEd.Program.pokepic_y = 3;
        }

        private void giveEgg(object sender, EventArgs e)
        {
            scriptBox.Text = scriptBox.Text + "Giveegg 0x"+convert.decToHex(eggPokeName.SelectedIndex)+" 'Gives an egg of "+eggPokeName.Text;
            scriptBox.Text = scriptBox.Text + System.Environment.NewLine;
        }

        private void movBt_Click(object sender, EventArgs e)
        {
            applyMovement mov = new applyMovement();
            mov.ShowDialog();
        }

        private void OpenAddMart(object sender, EventArgs e)
        {
            addShop mart = new addShop();
            mart.ShowDialog();
        }

        private void saveAllToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openAddStr(object sender, EventArgs e)
        {
            string oldStr = Program.sendString;
            addString str = new addString();
            str.ShowDialog();
            if(oldStr != Program.sendString)
            {
                stringBox.Items.Add("#org @" + Program.stringId + "|=" + Program.sendString);
                scriptBox.Text = scriptBox.Text + "msgbox @" + Program.stringId + " ";
                switch (Program.boxType)
                {
                    case 0: scriptBox.Text = scriptBox.Text + "0x0"; break;
                    case 1: scriptBox.Text = scriptBox.Text + "0x1"; break;
                    case 2: scriptBox.Text = scriptBox.Text + "0x2"; break;
                    case 3: scriptBox.Text = scriptBox.Text + "0x3"; break;
                    case 4: scriptBox.Text = scriptBox.Text + "0x4"; break;
                    case 5: scriptBox.Text = scriptBox.Text + "0x5" + Environment.NewLine + "compare 0x800D 0x" + Program.ynSel + Environment.NewLine + "0x1 " + Program.ynDo + " @" + Program.ynOff; break;
                    case 6: scriptBox.Text = scriptBox.Text + "0x6"; break;
                    case 7: scriptBox.Text = scriptBox.Text + "0xA"; break;
                    default: break;
                }
                scriptBox.Text = scriptBox.Text + Environment.NewLine;

            }
        }
    }
}
