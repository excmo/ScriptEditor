﻿namespace ScriptEd
{
    partial class addShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Master Ball");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Ultra Ball");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Super Ball");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Poke Ball");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Safari Ball");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Net Ball");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Dive Ball");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Nest Ball");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Repeat Ball");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Timer Ball");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Luxury Ball");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Premier Ball");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Balls", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Healing");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Etc.");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Berries");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Flutes");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("HP Up");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Protein");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Iron");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Carbos");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Calcium");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Rare Candy");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("PP Up");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Zinc");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("PP Max.");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Vitamines", new System.Windows.Forms.TreeNode[] {
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26});
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Guard Spec.");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Dire Hit");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("X Attack");
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("X Deffend");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("X Speed");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("X Accuracy");
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("X Special");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Battle Objects", new System.Windows.Forms.TreeNode[] {
            treeNode28,
            treeNode29,
            treeNode30,
            treeNode31,
            treeNode32,
            treeNode33,
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Sun Stone");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Moon Stone");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Fire Stone");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Thunder Stone");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Water Stone");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Leaf Stone");
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Evolution stones", new System.Windows.Forms.TreeNode[] {
            treeNode36,
            treeNode37,
            treeNode38,
            treeNode39,
            treeNode40,
            treeNode41});
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Mail");
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Boosting items");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("TM 01 (Focus punch)");
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("TM 02 (Dragon claw)");
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("TMs", new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46});
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("HM 01 (Cut)");
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("HM 02 (Fly)");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("HM 03 (Surf)");
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("HM 04 (Strength)");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("HM 05 (Light)");
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("HM 06 (Rock Smash)");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("HM 07 (Waterfall)");
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("HM 08 (Dive)");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("HMs", new System.Windows.Forms.TreeNode[] {
            treeNode48,
            treeNode49,
            treeNode50,
            treeNode51,
            treeNode52,
            treeNode53,
            treeNode54,
            treeNode55});
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("Key items");
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("Common", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17,
            treeNode27,
            treeNode35,
            treeNode42,
            treeNode43,
            treeNode44,
            treeNode47,
            treeNode56,
            treeNode57});
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("Oak\'s Parcel");
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Pokéflute");
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("Secret Key");
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("Key Items", new System.Windows.Forms.TreeNode[] {
            treeNode59,
            treeNode60,
            treeNode61});
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("FR / LG only", new System.Windows.Forms.TreeNode[] {
            treeNode62});
            System.Windows.Forms.TreeNode treeNode64 = new System.Windows.Forms.TreeNode("Magma Emblem");
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("Old Sea Map");
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("Key items", new System.Windows.Forms.TreeNode[] {
            treeNode64,
            treeNode65});
            System.Windows.Forms.TreeNode treeNode67 = new System.Windows.Forms.TreeNode("Emerald only", new System.Windows.Forms.TreeNode[] {
            treeNode66});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addShop));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btIns = new System.Windows.Forms.Button();
            this.btCl = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.itemList = new System.Windows.Forms.TreeView();
            this.itemIcons = new System.Windows.Forms.ImageList(this.components);
            this.itemBox = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.btUp = new System.Windows.Forms.Button();
            this.btRem = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(434, 326);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btIns, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btCl, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 289);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(428, 34);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // btIns
            // 
            this.btIns.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btIns.Location = new System.Drawing.Point(136, 5);
            this.btIns.Name = "btIns";
            this.btIns.Size = new System.Drawing.Size(75, 23);
            this.btIns.TabIndex = 0;
            this.btIns.Text = "Insert";
            this.btIns.UseVisualStyleBackColor = true;
            // 
            // btCl
            // 
            this.btCl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btCl.Location = new System.Drawing.Point(217, 5);
            this.btCl.Name = "btCl";
            this.btCl.Size = new System.Drawing.Size(75, 23);
            this.btCl.TabIndex = 1;
            this.btCl.Text = "Cancel";
            this.btCl.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.itemList, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.itemBox, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 43);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(428, 240);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // itemList
            // 
            this.itemList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemList.Location = new System.Drawing.Point(3, 3);
            this.itemList.Name = "itemList";
            treeNode1.Name = "x001";
            treeNode1.StateImageKey = "master.png";
            treeNode1.Text = "Master Ball";
            treeNode2.Name = "x002";
            treeNode2.StateImageKey = "ultra.png";
            treeNode2.Text = "Ultra Ball";
            treeNode3.Name = "x003";
            treeNode3.StateImageKey = "super.png";
            treeNode3.Text = "Super Ball";
            treeNode4.Name = "x004";
            treeNode4.StateImageKey = "ball.png";
            treeNode4.Text = "Poke Ball";
            treeNode5.Name = "x005";
            treeNode5.StateImageKey = "safari.png";
            treeNode5.Text = "Safari Ball";
            treeNode6.Name = "x006";
            treeNode6.StateImageKey = "net.png";
            treeNode6.Text = "Net Ball";
            treeNode7.Name = "x007";
            treeNode7.StateImageKey = "dive.png";
            treeNode7.Text = "Dive Ball";
            treeNode8.Name = "x008";
            treeNode8.StateImageKey = "nest.png";
            treeNode8.Text = "Nest Ball";
            treeNode9.Name = "x009";
            treeNode9.StateImageKey = "repeat.png";
            treeNode9.Text = "Repeat Ball";
            treeNode10.Name = "x00A";
            treeNode10.StateImageKey = "timer.png";
            treeNode10.Text = "Timer Ball";
            treeNode11.Name = "x00B";
            treeNode11.StateImageKey = "luxury.png";
            treeNode11.Text = "Luxury Ball";
            treeNode12.Name = "x00C";
            treeNode12.StateImageKey = "premier.png";
            treeNode12.Text = "Premier Ball";
            treeNode13.Name = "mkBalls";
            treeNode13.StateImageKey = "(ninguno)";
            treeNode13.Text = "Balls";
            treeNode14.Name = "mkHeal";
            treeNode14.Text = "Healing";
            treeNode15.Name = "mkEtc";
            treeNode15.Text = "Etc.";
            treeNode16.Name = "mkBerries";
            treeNode16.Text = "Berries";
            treeNode17.Name = "mkFlutes";
            treeNode17.Text = "Flutes";
            treeNode18.Name = "x03F";
            treeNode18.Text = "HP Up";
            treeNode19.Name = "x040";
            treeNode19.Text = "Protein";
            treeNode20.Name = "x041";
            treeNode20.Text = "Iron";
            treeNode21.Name = "x042";
            treeNode21.Text = "Carbos";
            treeNode22.Name = "x043";
            treeNode22.Text = "Calcium";
            treeNode23.Name = "x44";
            treeNode23.Text = "Rare Candy";
            treeNode24.Name = "x045";
            treeNode24.Text = "PP Up";
            treeNode25.Name = "x046";
            treeNode25.Text = "Zinc";
            treeNode26.Name = "x047";
            treeNode26.Text = "PP Max.";
            treeNode27.Name = "mkVits";
            treeNode27.Text = "Vitamines";
            treeNode28.Name = "x049";
            treeNode28.Text = "Guard Spec.";
            treeNode29.Name = "x04A";
            treeNode29.Text = "Dire Hit";
            treeNode30.Name = "x04B";
            treeNode30.Text = "X Attack";
            treeNode31.Name = "x04C";
            treeNode31.Text = "X Deffend";
            treeNode32.Name = "x04D";
            treeNode32.Text = "X Speed";
            treeNode33.Name = "x04D";
            treeNode33.Text = "X Accuracy";
            treeNode34.Name = "x04F";
            treeNode34.Text = "X Special";
            treeNode35.Name = "mkBattle";
            treeNode35.Text = "Battle Objects";
            treeNode36.Name = "x05D";
            treeNode36.Text = "Sun Stone";
            treeNode37.Name = "x05E";
            treeNode37.Text = "Moon Stone";
            treeNode38.Name = "x05F";
            treeNode38.Text = "Fire Stone";
            treeNode39.Name = "x060";
            treeNode39.Text = "Thunder Stone";
            treeNode40.Name = "x061";
            treeNode40.Text = "Water Stone";
            treeNode41.Name = "x062";
            treeNode41.Text = "Leaf Stone";
            treeNode42.Name = "mkEvoStones";
            treeNode42.Text = "Evolution stones";
            treeNode43.Name = "mkMail";
            treeNode43.Text = "Mail";
            treeNode44.Name = "mkPowUps";
            treeNode44.Text = "Boosting items";
            treeNode45.Name = "x121";
            treeNode45.Text = "TM 01 (Focus punch)";
            treeNode46.Name = "x122";
            treeNode46.Text = "TM 02 (Dragon claw)";
            treeNode47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            treeNode47.Name = "mkTechMach";
            treeNode47.Text = "TMs";
            treeNode48.Name = "x153";
            treeNode48.Text = "HM 01 (Cut)";
            treeNode49.Name = "x154";
            treeNode49.Text = "HM 02 (Fly)";
            treeNode50.Name = "x155";
            treeNode50.Text = "HM 03 (Surf)";
            treeNode51.Name = "x156";
            treeNode51.Text = "HM 04 (Strength)";
            treeNode52.Name = "x157";
            treeNode52.Text = "HM 05 (Light)";
            treeNode53.Name = "x158";
            treeNode53.Text = "HM 06 (Rock Smash)";
            treeNode54.Name = "x159";
            treeNode54.Text = "HM 07 (Waterfall)";
            treeNode55.Name = "x15A";
            treeNode55.Text = "HM 08 (Dive)";
            treeNode56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            treeNode56.Name = "mkHidMach";
            treeNode56.Text = "HMs";
            treeNode57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            treeNode57.Name = "mkKeyIts";
            treeNode57.Text = "Key items";
            treeNode58.Name = "com";
            treeNode58.StateImageIndex = 0;
            treeNode58.Text = "Common";
            treeNode59.Name = "x15D";
            treeNode59.Text = "Oak\'s Parcel";
            treeNode60.Name = "x15E";
            treeNode60.Text = "Pokéflute";
            treeNode61.Name = "x15F";
            treeNode61.Text = "Secret Key";
            treeNode62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            treeNode62.Name = "frKeyItem";
            treeNode62.Text = "Key Items";
            treeNode63.Name = "fr";
            treeNode63.StateImageIndex = 1;
            treeNode63.Text = "FR / LG only";
            treeNode64.Name = "x177";
            treeNode64.Text = "Magma Emblem";
            treeNode65.Name = "x178";
            treeNode65.Text = "Old Sea Map";
            treeNode66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            treeNode66.Name = "mkEmKey";
            treeNode66.Text = "Key items";
            treeNode67.Name = "em";
            treeNode67.StateImageIndex = 2;
            treeNode67.Text = "Emerald only";
            this.itemList.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode58,
            treeNode63,
            treeNode67});
            this.itemList.Size = new System.Drawing.Size(208, 234);
            this.itemList.StateImageList = this.itemIcons;
            this.itemList.TabIndex = 0;
            this.itemList.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.itemList_AfterSelect);
            // 
            // itemIcons
            // 
            this.itemIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("itemIcons.ImageStream")));
            this.itemIcons.TransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.itemIcons.Images.SetKeyName(0, "groudon.png");
            this.itemIcons.Images.SetKeyName(1, "chard.bmp");
            this.itemIcons.Images.SetKeyName(2, "rayq.png");
            this.itemIcons.Images.SetKeyName(3, "ball.png");
            this.itemIcons.Images.SetKeyName(4, "dive.png");
            this.itemIcons.Images.SetKeyName(5, "luxury.png");
            this.itemIcons.Images.SetKeyName(6, "master.png");
            this.itemIcons.Images.SetKeyName(7, "nest.png");
            this.itemIcons.Images.SetKeyName(8, "net.png");
            this.itemIcons.Images.SetKeyName(9, "premier.png");
            this.itemIcons.Images.SetKeyName(10, "repeat.png");
            this.itemIcons.Images.SetKeyName(11, "safari.png");
            this.itemIcons.Images.SetKeyName(12, "super.png");
            this.itemIcons.Images.SetKeyName(13, "timer.png");
            this.itemIcons.Images.SetKeyName(14, "ultra.png");
            // 
            // itemBox
            // 
            this.itemBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemBox.FormattingEnabled = true;
            this.itemBox.Location = new System.Drawing.Point(217, 3);
            this.itemBox.Name = "itemBox";
            this.itemBox.Size = new System.Drawing.Size(208, 234);
            this.itemBox.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.flowLayoutPanel2, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(428, 34);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.textBox1);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(208, 28);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pokemart ID:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(78, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "mart1";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.btUp);
            this.flowLayoutPanel2.Controls.Add(this.btRem);
            this.flowLayoutPanel2.Controls.Add(this.button1);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(217, 3);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(208, 28);
            this.flowLayoutPanel2.TabIndex = 6;
            // 
            // btUp
            // 
            this.btUp.Location = new System.Drawing.Point(3, 3);
            this.btUp.Name = "btUp";
            this.btUp.Size = new System.Drawing.Size(64, 23);
            this.btUp.TabIndex = 2;
            this.btUp.Text = "";
            this.btUp.UseVisualStyleBackColor = true;
            // 
            // btRem
            // 
            this.btRem.Location = new System.Drawing.Point(73, 3);
            this.btRem.Name = "btRem";
            this.btRem.Size = new System.Drawing.Size(60, 23);
            this.btRem.TabIndex = 3;
            this.btRem.Text = "Remove";
            this.btRem.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(139, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // addShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 326);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "addShop";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Pokemart";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btIns;
        private System.Windows.Forms.Button btCl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TreeView itemList;
        private System.Windows.Forms.ImageList itemIcons;
        private System.Windows.Forms.ListBox itemBox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button btUp;
        private System.Windows.Forms.Button btRem;
        private System.Windows.Forms.Button button1;
    }
}