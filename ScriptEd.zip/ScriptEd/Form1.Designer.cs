﻿namespace ScriptEd
{
    partial class mainWindow
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainWindow));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.romTypeText = new System.Windows.Forms.ToolStripLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.calcTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.DTH = new System.Windows.Forms.TextBox();
            this.copyDec_bt = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.decToHex_bt = new System.Windows.Forms.Button();
            this.hexToDec_bt = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.HTD = new System.Windows.Forms.TextBox();
            this.copyHex_bt = new System.Windows.Forms.Button();
            this.pokeTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel16 = new System.Windows.Forms.FlowLayoutPanel();
            this.btGiveEgg = new System.Windows.Forms.Button();
            this.flowLayoutPanel17 = new System.Windows.Forms.FlowLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.eggPokeName = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.picPokeName = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pokepicX = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.pokepicY = new System.Windows.Forms.NumericUpDown();
            this.flowLayoutPanel10 = new System.Windows.Forms.FlowLayoutPanel();
            this.btPokePic = new System.Windows.Forms.Button();
            this.btPrevPic = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel11 = new System.Windows.Forms.FlowLayoutPanel();
            this.btWildPoke = new System.Windows.Forms.Button();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.wildPokeName = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.wildPokeLevel = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.wildPokeItem = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel12 = new System.Windows.Forms.FlowLayoutPanel();
            this.btGivePoke = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.givePokeName = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.givePokeLevel = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.givePokeItem = new System.Windows.Forms.ComboBox();
            this.itemTab = new System.Windows.Forms.TabPage();
            this.quickTable = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel15 = new System.Windows.Forms.FlowLayoutPanel();
            this.button8 = new System.Windows.Forms.Button();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.itemTable = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel13 = new System.Windows.Forms.FlowLayoutPanel();
            this.button6 = new System.Windows.Forms.Button();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel14 = new System.Windows.Forms.FlowLayoutPanel();
            this.button7 = new System.Windows.Forms.Button();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.soundTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button4 = new System.Windows.Forms.Button();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.scriptBox = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.stringBox = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.nuevoToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.abrirToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.guardarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cortarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copiarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pegarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.movBt = new System.Windows.Forms.ToolStripButton();
            this.martBt = new System.Windows.Forms.ToolStripButton();
            this.addStrBt = new System.Windows.Forms.ToolStripButton();
            this.closeKeypressBt = new System.Windows.Forms.ToolStripButton();
            this.newScriptBt = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.lockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lockAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.releaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.releaseAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faceplayerBt = new System.Windows.Forms.ToolStripButton();
            this.ayudaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.calcTab.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.pokeTab.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.flowLayoutPanel16.SuspendLayout();
            this.flowLayoutPanel17.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pokepicX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokepicY)).BeginInit();
            this.flowLayoutPanel10.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.flowLayoutPanel11.SuspendLayout();
            this.flowLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wildPokeLevel)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.flowLayoutPanel12.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.givePokeLevel)).BeginInit();
            this.itemTab.SuspendLayout();
            this.quickTable.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.flowLayoutPanel15.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.itemTable.SuspendLayout();
            this.flowLayoutPanel13.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.flowLayoutPanel14.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.soundTab.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.flowLayoutPanel7.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1099, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoToolStripButton,
            this.abrirToolStripButton,
            this.guardarToolStripButton,
            this.toolStripSeparator,
            this.cortarToolStripButton,
            this.copiarToolStripButton,
            this.pegarToolStripButton,
            this.toolStripSeparator1,
            this.movBt,
            this.martBt,
            this.addStrBt,
            this.closeKeypressBt,
            this.toolStripSeparator3,
            this.newScriptBt,
            this.toolStripButton1,
            this.faceplayerBt,
            this.toolStripSeparator2,
            this.ayudaToolStripButton,
            this.romTypeText});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1099, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // romTypeText
            // 
            this.romTypeText.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.romTypeText.BackColor = System.Drawing.SystemColors.Control;
            this.romTypeText.ForeColor = System.Drawing.SystemColors.Control;
            this.romTypeText.Name = "romTypeText";
            this.romTypeText.Size = new System.Drawing.Size(58, 22);
            this.romTypeText.Text = "Rom type";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.splitContainer1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 49);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1099, 564);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(802, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(294, 558);
            this.panel1.TabIndex = 0;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.calcTab);
            this.tabControl3.Controls.Add(this.pokeTab);
            this.tabControl3.Controls.Add(this.itemTab);
            this.tabControl3.Controls.Add(this.soundTab);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Multiline = true;
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(294, 558);
            this.tabControl3.TabIndex = 0;
            // 
            // calcTab
            // 
            this.calcTab.Controls.Add(this.tableLayoutPanel2);
            this.calcTab.Location = new System.Drawing.Point(4, 22);
            this.calcTab.Name = "calcTab";
            this.calcTab.Padding = new System.Windows.Forms.Padding(3);
            this.calcTab.Size = new System.Drawing.Size(286, 532);
            this.calcTab.TabIndex = 0;
            this.calcTab.Text = "Calculator";
            this.calcTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.42647F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.57353F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(280, 526);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 111);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Conversor";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.DTH);
            this.flowLayoutPanel1.Controls.Add(this.copyDec_bt);
            this.flowLayoutPanel1.Controls.Add(this.tableLayoutPanel4);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.HTD);
            this.flowLayoutPanel1.Controls.Add(this.copyHex_bt);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(268, 106);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "DEC:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DTH
            // 
            this.DTH.Location = new System.Drawing.Point(49, 3);
            this.DTH.Name = "DTH";
            this.DTH.Size = new System.Drawing.Size(130, 20);
            this.DTH.TabIndex = 9;
            this.DTH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // copyDec_bt
            // 
            this.copyDec_bt.Location = new System.Drawing.Point(185, 3);
            this.copyDec_bt.Name = "copyDec_bt";
            this.copyDec_bt.Size = new System.Drawing.Size(30, 20);
            this.copyDec_bt.TabIndex = 6;
            this.copyDec_bt.Text = "";
            this.copyDec_bt.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.98473F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.01527F));
            this.tableLayoutPanel4.Controls.Add(this.decToHex_bt, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.hexToDec_bt, 1, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 29);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(262, 29);
            this.tableLayoutPanel4.TabIndex = 8;
            // 
            // decToHex_bt
            // 
            this.decToHex_bt.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.decToHex_bt.Location = new System.Drawing.Point(48, 3);
            this.decToHex_bt.Name = "decToHex_bt";
            this.decToHex_bt.Size = new System.Drawing.Size(58, 23);
            this.decToHex_bt.TabIndex = 5;
            this.decToHex_bt.Text = "⏷ HEX";
            this.decToHex_bt.UseVisualStyleBackColor = true;
            this.decToHex_bt.Click += new System.EventHandler(this.decToHex);
            // 
            // hexToDec_bt
            // 
            this.hexToDec_bt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.hexToDec_bt.Location = new System.Drawing.Point(112, 3);
            this.hexToDec_bt.Name = "hexToDec_bt";
            this.hexToDec_bt.Size = new System.Drawing.Size(59, 23);
            this.hexToDec_bt.TabIndex = 4;
            this.hexToDec_bt.Text = "⏶ DEC";
            this.hexToDec_bt.UseVisualStyleBackColor = true;
            this.hexToDec_bt.Click += new System.EventHandler(this.hexToDec);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(3, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "HEX:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // HTD
            // 
            this.HTD.Location = new System.Drawing.Point(49, 64);
            this.HTD.Name = "HTD";
            this.HTD.Size = new System.Drawing.Size(130, 20);
            this.HTD.TabIndex = 3;
            this.HTD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // copyHex_bt
            // 
            this.copyHex_bt.Location = new System.Drawing.Point(185, 64);
            this.copyHex_bt.Name = "copyHex_bt";
            this.copyHex_bt.Size = new System.Drawing.Size(30, 20);
            this.copyHex_bt.TabIndex = 7;
            this.copyHex_bt.Text = "";
            this.copyHex_bt.UseVisualStyleBackColor = true;
            // 
            // pokeTab
            // 
            this.pokeTab.Controls.Add(this.tableLayoutPanel3);
            this.pokeTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pokeTab.Location = new System.Drawing.Point(4, 22);
            this.pokeTab.Name = "pokeTab";
            this.pokeTab.Padding = new System.Windows.Forms.Padding(3);
            this.pokeTab.Size = new System.Drawing.Size(286, 532);
            this.pokeTab.TabIndex = 1;
            this.pokeTab.Text = "Pokémon";
            this.pokeTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.groupBox9, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.groupBox6, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.groupBox5, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(280, 526);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tableLayoutPanel13);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(3, 128);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(274, 119);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Give egg";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.flowLayoutPanel16, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.flowLayoutPanel17, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // flowLayoutPanel16
            // 
            this.flowLayoutPanel16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel16.AutoSize = true;
            this.flowLayoutPanel16.Controls.Add(this.btGiveEgg);
            this.flowLayoutPanel16.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel16.Name = "flowLayoutPanel16";
            this.flowLayoutPanel16.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel16.TabIndex = 10;
            // 
            // btGiveEgg
            // 
            this.btGiveEgg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btGiveEgg.Location = new System.Drawing.Point(3, 3);
            this.btGiveEgg.Name = "btGiveEgg";
            this.btGiveEgg.Size = new System.Drawing.Size(75, 23);
            this.btGiveEgg.TabIndex = 13;
            this.btGiveEgg.Text = "<< Insert";
            this.btGiveEgg.UseVisualStyleBackColor = true;
            this.btGiveEgg.Click += new System.EventHandler(this.giveEgg);
            // 
            // flowLayoutPanel17
            // 
            this.flowLayoutPanel17.Controls.Add(this.label21);
            this.flowLayoutPanel17.Controls.Add(this.eggPokeName);
            this.flowLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel17.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel17.Name = "flowLayoutPanel17";
            this.flowLayoutPanel17.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel17.TabIndex = 9;
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 21);
            this.label21.TabIndex = 0;
            this.label21.Text = "Give an egg of";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // eggPokeName
            // 
            this.eggPokeName.FormattingEnabled = true;
            this.eggPokeName.Items.AddRange(new object[] {
            "??????????",
            "BULBASAUR",
            "IVYSAUR",
            "VENUSAUR",
            "CHARMANDER",
            "CHARMELEON",
            "CHARIZARD",
            "SQUIRTLE",
            "WARTORTLE",
            "BLASTOISE",
            "CATERPIE",
            "METAPOD",
            "BUTTERFREE",
            "WEEDLE",
            "KAKUNA",
            "BEEDRILL",
            "PIDGEY",
            "PIDGEOTTO",
            "PIDGEOT",
            "RATTATA",
            "RATICATE",
            "SPEAROW",
            "FEAROW",
            "EKANS",
            "ARBOK",
            "PIKACHU",
            "RAICHU",
            "SANDSHREW",
            "SANDSLASH",
            "NIDORAN[F]",
            "NIDORINA",
            "NIDOQUEEN",
            "NIDORAN[M]",
            "NIDORINO",
            "NIDOKING",
            "CLEFAIRY",
            "CLEFABLE",
            "VULPIX",
            "NINETALES",
            "JIGGLYPUFF",
            "WIGGLYTUFF",
            "ZUBAT",
            "GOLBAT",
            "ODDISH",
            "GLOOM",
            "VILEPLUME",
            "PARAS",
            "PARASECT",
            "VENONAT",
            "VENOMOTH",
            "DIGLETT",
            "DUGTRIO",
            "MEOWTH",
            "PERSIAN",
            "PSYDUCK",
            "GOLDUCK",
            "MANKEY",
            "PRIMEAPE",
            "GROWLITHE",
            "ARCANINE",
            "POLIWAG",
            "POLIWHIRL",
            "POLIWRATH",
            "ABRA",
            "KADABRA",
            "ALAKAZAM",
            "MACHOP",
            "MACHOKE",
            "MACHAMP",
            "BELLSPROUT",
            "WEEPINBELL",
            "VICTREEBEL",
            "TENTACOOL",
            "TENTACRUEL",
            "GEODUDE",
            "GRAVELER",
            "GOLEM",
            "PONYTA",
            "RAPIDASH",
            "SLOWPOKE",
            "SLOWBRO",
            "MAGNEMITE",
            "MAGNETON",
            "FARFETCHED",
            "DODUO",
            "DODRIO",
            "SEEL",
            "DEWGONG",
            "GRIMER",
            "MUK",
            "SHELLDER",
            "CLOYSTER",
            "GASTLY",
            "HAUNTER",
            "GENGAR",
            "ONIX",
            "DROWZEE",
            "HYPNO",
            "KRABBY",
            "KINGLER",
            "VOLTORB",
            "ELECTRODE",
            "EXEGGCUTE",
            "EXEGGUTOR",
            "CUBONE",
            "MAROWAK",
            "HITMONLEE",
            "HITMONCHAN",
            "LICKITUNG",
            "KOFFING",
            "WEEZING",
            "RHYHORN",
            "RHYDON",
            "CHANSEY",
            "TANGELA",
            "KANGASKHAN",
            "HORSEA",
            "SEADRA",
            "GOLDEEN",
            "SEAKING",
            "STARYU",
            "STARMIE",
            "MRMIME",
            "SCYTHER",
            "JYNX",
            "ELECTABUZZ",
            "MAGMAR",
            "PINSIR",
            "TAUROS",
            "MAGIKARP",
            "GYARADOS",
            "LAPRAS",
            "DITTO",
            "EEVEE",
            "VAPOREON",
            "JOLTEON",
            "FLAREON",
            "PORYGON",
            "OMANYTE",
            "OMASTAR",
            "KABUTO",
            "KABUTOPS",
            "AERODACTYL",
            "SNORLAX",
            "ARTICUNO",
            "ZAPDOS",
            "MOLTRES",
            "DRATINI",
            "DRAGONAIR",
            "DRAGONITE",
            "MEWTWO",
            "MEW",
            "CHIKORITA",
            "BAYLEEF",
            "MEGANIUM",
            "CYNDAQUIL",
            "QUILAVA",
            "TYPHLOSION",
            "TOTODILE",
            "CROCONAW",
            "FERALIGATR",
            "SENTRET",
            "FURRET",
            "HOOTHOOT",
            "NOCTOWL",
            "LEDYBA",
            "LEDIAN",
            "SPINARAK",
            "ARIADOS",
            "CROBAT",
            "CHINCHOU",
            "LANTURN",
            "PICHU",
            "CLEFFA",
            "IGGLYBUFF",
            "TOGEPI",
            "TOGETIC",
            "NATU",
            "XATU",
            "MAREEP",
            "FLAAFFY",
            "AMPHAROS",
            "BELLOSSOM",
            "MARILL",
            "AZUMARILL",
            "SUDOWOODO",
            "POLITOED",
            "HOPPIP",
            "SKIPLOOM",
            "JUMPLUFF",
            "AIPOM",
            "SUNKERN",
            "SUNFLORA",
            "YANMA",
            "WOOPER",
            "QUAGSIRE",
            "ESPEON",
            "UMBREON",
            "MURKROW",
            "SLOWKING",
            "MISDREAVUS",
            "UNOWN",
            "WOBBUFFET",
            "GIRAFARIG",
            "PINECO",
            "FORRETRESS",
            "DUNSPARCE",
            "GLIGAR",
            "STEELIX",
            "SNUBBULL",
            "GRANBULL",
            "QWILFISH",
            "SCIZOR",
            "SHUCKLE",
            "HERACROSS",
            "SNEASEL",
            "TEDDIURSA",
            "URSARING",
            "SLUGMA",
            "MAGCARGO",
            "SWINUB",
            "PILOSWINE",
            "CORSOLA",
            "REMORAID",
            "OCTILLERY",
            "DELIBIRD",
            "MANTINE",
            "SKARMORY",
            "HOUNDOUR",
            "HOUNDOOM",
            "KINGDRA",
            "PHANPY",
            "DONPHAN",
            "PORYGON",
            "STANTLER",
            "SMEARGLE",
            "TYROGUE",
            "HITMONTOP",
            "SMOOCHUM",
            "ELEKID",
            "MAGBY",
            "MILTANK",
            "BLISSEY",
            "RAIKOU",
            "ENTEI",
            "SUICUNE",
            "LARVITAR",
            "PUPITAR",
            "TYRANITAR",
            "LUGIA",
            "HOOH",
            "CELEBI",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "TREECKO",
            "GROVYLE",
            "SCEPTILE",
            "TORCHIC",
            "COMBUSKEN",
            "BLAZIKEN",
            "MUDKIP",
            "MARSHTOMP",
            "SWAMPERT",
            "POOCHYENA",
            "MIGHTYENA",
            "ZIGZAGOON",
            "LINOONE",
            "WURMPLE",
            "SILCOON",
            "BEAUTIFLY",
            "CASCOON",
            "DUSTOX",
            "LOTAD",
            "LOMBRE",
            "LUDICOLO",
            "SEEDOT",
            "NUZLEAF",
            "SHIFTRY",
            "NINCADA",
            "NINJASK",
            "SHEDINJA",
            "TAILLOW",
            "SWELLOW",
            "SHROOMISH",
            "BRELOOM",
            "SPINDA",
            "WINGULL",
            "PELIPPER",
            "SURSKIT",
            "MASQUERAIN",
            "WAILMER",
            "WAILORD",
            "SKITTY",
            "DELCATTY",
            "KECLEON",
            "BALTOY",
            "CLAYDOL",
            "NOSEPASS",
            "TORKOAL",
            "SABLEYE",
            "BARBOACH",
            "WHISCASH",
            "LUVDISC",
            "CORPHISH",
            "CRAWDAUNT",
            "FEEBAS",
            "MILOTIC",
            "CARVANHA",
            "SHARPEDO",
            "TRAPINCH",
            "VIBRAVA",
            "FLYGON",
            "MAKUHITA",
            "HARIYAMA",
            "ELECTRIKE",
            "MANECTRIC",
            "NUMEL",
            "CAMERUPT",
            "SPHEAL",
            "SEALEO",
            "WALREIN",
            "CACNEA",
            "CACTURNE",
            "SNORUNT",
            "GLALIE",
            "LUNATONE",
            "SOLROCK",
            "AZURILL",
            "SPOINK",
            "GRUMPIG",
            "PLUSLE",
            "MINUN",
            "MAWILE",
            "MEDITITE",
            "MEDICHAM",
            "SWABLU",
            "ALTARIA",
            "WYNAUT",
            "DUSKULL",
            "DUSCLOPS",
            "ROSELIA",
            "SLAKOTH",
            "VIGOROTH",
            "SLAKING",
            "GULPIN",
            "SWALOT",
            "TROPIUS",
            "WHISMUR",
            "LOUDRED",
            "EXPLOUD",
            "CLAMPERL",
            "HUNTAIL",
            "GOREBYSS",
            "ABSOL",
            "SHUPPET",
            "BANETTE",
            "SEVIPER",
            "ZANGOOSE",
            "RELICANTH",
            "ARON",
            "LAIRON",
            "AGGRON",
            "CASTFORM",
            "VOLBEAT",
            "ILLUMISE",
            "LILEEP",
            "CRADILY",
            "ANORITH",
            "ARMALDO",
            "RALTS",
            "KIRLIA",
            "GARDEVOIR",
            "BAGON",
            "SHELGON",
            "SALAMENCE",
            "BELDUM",
            "METANG",
            "METAGROSS",
            "REGIROCK",
            "REGICE",
            "REGISTEEL",
            "KYOGRE",
            "GROUDON",
            "RAYQUAZA",
            "LATIAS",
            "LATIOS",
            "JIRACHI",
            "DEOXYS",
            "CHIMECHO"});
            this.eggPokeName.Location = new System.Drawing.Point(89, 3);
            this.eggPokeName.Name = "eggPokeName";
            this.eggPokeName.Size = new System.Drawing.Size(100, 21);
            this.eggPokeName.TabIndex = 1;
            // 
            // groupBox6
            // 
            this.groupBox6.AutoSize = true;
            this.groupBox6.Controls.Add(this.tableLayoutPanel6);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 378);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(274, 119);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Show picture";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel9, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.flowLayoutPanel10, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel6.TabIndex = 5;
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.Controls.Add(this.label15);
            this.flowLayoutPanel9.Controls.Add(this.picPokeName);
            this.flowLayoutPanel9.Controls.Add(this.label17);
            this.flowLayoutPanel9.Controls.Add(this.label16);
            this.flowLayoutPanel9.Controls.Add(this.pokepicX);
            this.flowLayoutPanel9.Controls.Add(this.label18);
            this.flowLayoutPanel9.Controls.Add(this.pokepicY);
            this.flowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel9.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel9.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 21);
            this.label15.TabIndex = 8;
            this.label15.Text = "Show picture of";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picPokeName
            // 
            this.picPokeName.FormattingEnabled = true;
            this.picPokeName.Items.AddRange(new object[] {
            "??????????",
            "BULBASAUR",
            "IVYSAUR",
            "VENUSAUR",
            "CHARMANDER",
            "CHARMELEON",
            "CHARIZARD",
            "SQUIRTLE",
            "WARTORTLE",
            "BLASTOISE",
            "CATERPIE",
            "METAPOD",
            "BUTTERFREE",
            "WEEDLE",
            "KAKUNA",
            "BEEDRILL",
            "PIDGEY",
            "PIDGEOTTO",
            "PIDGEOT",
            "RATTATA",
            "RATICATE",
            "SPEAROW",
            "FEAROW",
            "EKANS",
            "ARBOK",
            "PIKACHU",
            "RAICHU",
            "SANDSHREW",
            "SANDSLASH",
            "NIDORAN[F]",
            "NIDORINA",
            "NIDOQUEEN",
            "NIDORAN[M]",
            "NIDORINO",
            "NIDOKING",
            "CLEFAIRY",
            "CLEFABLE",
            "VULPIX",
            "NINETALES",
            "JIGGLYPUFF",
            "WIGGLYTUFF",
            "ZUBAT",
            "GOLBAT",
            "ODDISH",
            "GLOOM",
            "VILEPLUME",
            "PARAS",
            "PARASECT",
            "VENONAT",
            "VENOMOTH",
            "DIGLETT",
            "DUGTRIO",
            "MEOWTH",
            "PERSIAN",
            "PSYDUCK",
            "GOLDUCK",
            "MANKEY",
            "PRIMEAPE",
            "GROWLITHE",
            "ARCANINE",
            "POLIWAG",
            "POLIWHIRL",
            "POLIWRATH",
            "ABRA",
            "KADABRA",
            "ALAKAZAM",
            "MACHOP",
            "MACHOKE",
            "MACHAMP",
            "BELLSPROUT",
            "WEEPINBELL",
            "VICTREEBEL",
            "TENTACOOL",
            "TENTACRUEL",
            "GEODUDE",
            "GRAVELER",
            "GOLEM",
            "PONYTA",
            "RAPIDASH",
            "SLOWPOKE",
            "SLOWBRO",
            "MAGNEMITE",
            "MAGNETON",
            "FARFETCHED",
            "DODUO",
            "DODRIO",
            "SEEL",
            "DEWGONG",
            "GRIMER",
            "MUK",
            "SHELLDER",
            "CLOYSTER",
            "GASTLY",
            "HAUNTER",
            "GENGAR",
            "ONIX",
            "DROWZEE",
            "HYPNO",
            "KRABBY",
            "KINGLER",
            "VOLTORB",
            "ELECTRODE",
            "EXEGGCUTE",
            "EXEGGUTOR",
            "CUBONE",
            "MAROWAK",
            "HITMONLEE",
            "HITMONCHAN",
            "LICKITUNG",
            "KOFFING",
            "WEEZING",
            "RHYHORN",
            "RHYDON",
            "CHANSEY",
            "TANGELA",
            "KANGASKHAN",
            "HORSEA",
            "SEADRA",
            "GOLDEEN",
            "SEAKING",
            "STARYU",
            "STARMIE",
            "MRMIME",
            "SCYTHER",
            "JYNX",
            "ELECTABUZZ",
            "MAGMAR",
            "PINSIR",
            "TAUROS",
            "MAGIKARP",
            "GYARADOS",
            "LAPRAS",
            "DITTO",
            "EEVEE",
            "VAPOREON",
            "JOLTEON",
            "FLAREON",
            "PORYGON",
            "OMANYTE",
            "OMASTAR",
            "KABUTO",
            "KABUTOPS",
            "AERODACTYL",
            "SNORLAX",
            "ARTICUNO",
            "ZAPDOS",
            "MOLTRES",
            "DRATINI",
            "DRAGONAIR",
            "DRAGONITE",
            "MEWTWO",
            "MEW",
            "CHIKORITA",
            "BAYLEEF",
            "MEGANIUM",
            "CYNDAQUIL",
            "QUILAVA",
            "TYPHLOSION",
            "TOTODILE",
            "CROCONAW",
            "FERALIGATR",
            "SENTRET",
            "FURRET",
            "HOOTHOOT",
            "NOCTOWL",
            "LEDYBA",
            "LEDIAN",
            "SPINARAK",
            "ARIADOS",
            "CROBAT",
            "CHINCHOU",
            "LANTURN",
            "PICHU",
            "CLEFFA",
            "IGGLYBUFF",
            "TOGEPI",
            "TOGETIC",
            "NATU",
            "XATU",
            "MAREEP",
            "FLAAFFY",
            "AMPHAROS",
            "BELLOSSOM",
            "MARILL",
            "AZUMARILL",
            "SUDOWOODO",
            "POLITOED",
            "HOPPIP",
            "SKIPLOOM",
            "JUMPLUFF",
            "AIPOM",
            "SUNKERN",
            "SUNFLORA",
            "YANMA",
            "WOOPER",
            "QUAGSIRE",
            "ESPEON",
            "UMBREON",
            "MURKROW",
            "SLOWKING",
            "MISDREAVUS",
            "UNOWN",
            "WOBBUFFET",
            "GIRAFARIG",
            "PINECO",
            "FORRETRESS",
            "DUNSPARCE",
            "GLIGAR",
            "STEELIX",
            "SNUBBULL",
            "GRANBULL",
            "QWILFISH",
            "SCIZOR",
            "SHUCKLE",
            "HERACROSS",
            "SNEASEL",
            "TEDDIURSA",
            "URSARING",
            "SLUGMA",
            "MAGCARGO",
            "SWINUB",
            "PILOSWINE",
            "CORSOLA",
            "REMORAID",
            "OCTILLERY",
            "DELIBIRD",
            "MANTINE",
            "SKARMORY",
            "HOUNDOUR",
            "HOUNDOOM",
            "KINGDRA",
            "PHANPY",
            "DONPHAN",
            "PORYGON",
            "STANTLER",
            "SMEARGLE",
            "TYROGUE",
            "HITMONTOP",
            "SMOOCHUM",
            "ELEKID",
            "MAGBY",
            "MILTANK",
            "BLISSEY",
            "RAIKOU",
            "ENTEI",
            "SUICUNE",
            "LARVITAR",
            "PUPITAR",
            "TYRANITAR",
            "LUGIA",
            "HOOH",
            "CELEBI",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "TREECKO",
            "GROVYLE",
            "SCEPTILE",
            "TORCHIC",
            "COMBUSKEN",
            "BLAZIKEN",
            "MUDKIP",
            "MARSHTOMP",
            "SWAMPERT",
            "POOCHYENA",
            "MIGHTYENA",
            "ZIGZAGOON",
            "LINOONE",
            "WURMPLE",
            "SILCOON",
            "BEAUTIFLY",
            "CASCOON",
            "DUSTOX",
            "LOTAD",
            "LOMBRE",
            "LUDICOLO",
            "SEEDOT",
            "NUZLEAF",
            "SHIFTRY",
            "NINCADA",
            "NINJASK",
            "SHEDINJA",
            "TAILLOW",
            "SWELLOW",
            "SHROOMISH",
            "BRELOOM",
            "SPINDA",
            "WINGULL",
            "PELIPPER",
            "SURSKIT",
            "MASQUERAIN",
            "WAILMER",
            "WAILORD",
            "SKITTY",
            "DELCATTY",
            "KECLEON",
            "BALTOY",
            "CLAYDOL",
            "NOSEPASS",
            "TORKOAL",
            "SABLEYE",
            "BARBOACH",
            "WHISCASH",
            "LUVDISC",
            "CORPHISH",
            "CRAWDAUNT",
            "FEEBAS",
            "MILOTIC",
            "CARVANHA",
            "SHARPEDO",
            "TRAPINCH",
            "VIBRAVA",
            "FLYGON",
            "MAKUHITA",
            "HARIYAMA",
            "ELECTRIKE",
            "MANECTRIC",
            "NUMEL",
            "CAMERUPT",
            "SPHEAL",
            "SEALEO",
            "WALREIN",
            "CACNEA",
            "CACTURNE",
            "SNORUNT",
            "GLALIE",
            "LUNATONE",
            "SOLROCK",
            "AZURILL",
            "SPOINK",
            "GRUMPIG",
            "PLUSLE",
            "MINUN",
            "MAWILE",
            "MEDITITE",
            "MEDICHAM",
            "SWABLU",
            "ALTARIA",
            "WYNAUT",
            "DUSKULL",
            "DUSCLOPS",
            "ROSELIA",
            "SLAKOTH",
            "VIGOROTH",
            "SLAKING",
            "GULPIN",
            "SWALOT",
            "TROPIUS",
            "WHISMUR",
            "LOUDRED",
            "EXPLOUD",
            "CLAMPERL",
            "HUNTAIL",
            "GOREBYSS",
            "ABSOL",
            "SHUPPET",
            "BANETTE",
            "SEVIPER",
            "ZANGOOSE",
            "RELICANTH",
            "ARON",
            "LAIRON",
            "AGGRON",
            "CASTFORM",
            "VOLBEAT",
            "ILLUMISE",
            "LILEEP",
            "CRADILY",
            "ANORITH",
            "ARMALDO",
            "RALTS",
            "KIRLIA",
            "GARDEVOIR",
            "BAGON",
            "SHELGON",
            "SALAMENCE",
            "BELDUM",
            "METANG",
            "METAGROSS",
            "REGIROCK",
            "REGICE",
            "REGISTEEL",
            "KYOGRE",
            "GROUDON",
            "RAYQUAZA",
            "LATIAS",
            "LATIOS",
            "JIRACHI",
            "DEOXYS",
            "CHIMECHO"});
            this.picPokeName.Location = new System.Drawing.Point(92, 3);
            this.picPokeName.Name = "picPokeName";
            this.picPokeName.Size = new System.Drawing.Size(100, 21);
            this.picPokeName.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(198, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 21);
            this.label17.TabIndex = 11;
            this.label17.Text = "placed at:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(3, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 21);
            this.label16.TabIndex = 17;
            this.label16.Text = "X=";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pokepicX
            // 
            this.pokepicX.Location = new System.Drawing.Point(29, 30);
            this.pokepicX.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.pokepicX.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.pokepicX.Name = "pokepicX";
            this.pokepicX.Size = new System.Drawing.Size(35, 20);
            this.pokepicX.TabIndex = 15;
            this.pokepicX.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(70, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 21);
            this.label18.TabIndex = 18;
            this.label18.Text = "Y=";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pokepicY
            // 
            this.pokepicY.Location = new System.Drawing.Point(96, 30);
            this.pokepicY.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.pokepicY.Name = "pokepicY";
            this.pokepicY.Size = new System.Drawing.Size(35, 20);
            this.pokepicY.TabIndex = 16;
            this.pokepicY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // flowLayoutPanel10
            // 
            this.flowLayoutPanel10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel10.AutoSize = true;
            this.flowLayoutPanel10.Controls.Add(this.btPokePic);
            this.flowLayoutPanel10.Controls.Add(this.btPrevPic);
            this.flowLayoutPanel10.Location = new System.Drawing.Point(53, 65);
            this.flowLayoutPanel10.Name = "flowLayoutPanel10";
            this.flowLayoutPanel10.Size = new System.Drawing.Size(162, 29);
            this.flowLayoutPanel10.TabIndex = 5;
            // 
            // btPokePic
            // 
            this.btPokePic.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btPokePic.Location = new System.Drawing.Point(3, 3);
            this.btPokePic.Name = "btPokePic";
            this.btPokePic.Size = new System.Drawing.Size(75, 23);
            this.btPokePic.TabIndex = 13;
            this.btPokePic.Text = "<< Insert";
            this.btPokePic.UseVisualStyleBackColor = true;
            // 
            // btPrevPic
            // 
            this.btPrevPic.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btPrevPic.Location = new System.Drawing.Point(84, 3);
            this.btPrevPic.Name = "btPrevPic";
            this.btPrevPic.Size = new System.Drawing.Size(75, 23);
            this.btPrevPic.TabIndex = 19;
            this.btPrevPic.Text = "Preview";
            this.btPrevPic.UseVisualStyleBackColor = true;
            this.btPrevPic.Click += new System.EventHandler(this.advPic_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tableLayoutPanel8);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(3, 253);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(274, 119);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Wild encounter";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.flowLayoutPanel11, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.flowLayoutPanel8, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // flowLayoutPanel11
            // 
            this.flowLayoutPanel11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel11.AutoSize = true;
            this.flowLayoutPanel11.Controls.Add(this.btWildPoke);
            this.flowLayoutPanel11.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel11.Name = "flowLayoutPanel11";
            this.flowLayoutPanel11.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel11.TabIndex = 6;
            // 
            // btWildPoke
            // 
            this.btWildPoke.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btWildPoke.Location = new System.Drawing.Point(3, 3);
            this.btWildPoke.Name = "btWildPoke";
            this.btWildPoke.Size = new System.Drawing.Size(75, 23);
            this.btWildPoke.TabIndex = 13;
            this.btWildPoke.Text = "<< Insert";
            this.btWildPoke.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Controls.Add(this.label6);
            this.flowLayoutPanel8.Controls.Add(this.wildPokeName);
            this.flowLayoutPanel8.Controls.Add(this.label7);
            this.flowLayoutPanel8.Controls.Add(this.wildPokeLevel);
            this.flowLayoutPanel8.Controls.Add(this.label8);
            this.flowLayoutPanel8.Controls.Add(this.wildPokeItem);
            this.flowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel8.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 21);
            this.label6.TabIndex = 8;
            this.label6.Text = "Battle a";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // wildPokeName
            // 
            this.wildPokeName.FormattingEnabled = true;
            this.wildPokeName.Items.AddRange(new object[] {
            "??????????",
            "BULBASAUR",
            "IVYSAUR",
            "VENUSAUR",
            "CHARMANDER",
            "CHARMELEON",
            "CHARIZARD",
            "SQUIRTLE",
            "WARTORTLE",
            "BLASTOISE",
            "CATERPIE",
            "METAPOD",
            "BUTTERFREE",
            "WEEDLE",
            "KAKUNA",
            "BEEDRILL",
            "PIDGEY",
            "PIDGEOTTO",
            "PIDGEOT",
            "RATTATA",
            "RATICATE",
            "SPEAROW",
            "FEAROW",
            "EKANS",
            "ARBOK",
            "PIKACHU",
            "RAICHU",
            "SANDSHREW",
            "SANDSLASH",
            "NIDORAN[F]",
            "NIDORINA",
            "NIDOQUEEN",
            "NIDORAN[M]",
            "NIDORINO",
            "NIDOKING",
            "CLEFAIRY",
            "CLEFABLE",
            "VULPIX",
            "NINETALES",
            "JIGGLYPUFF",
            "WIGGLYTUFF",
            "ZUBAT",
            "GOLBAT",
            "ODDISH",
            "GLOOM",
            "VILEPLUME",
            "PARAS",
            "PARASECT",
            "VENONAT",
            "VENOMOTH",
            "DIGLETT",
            "DUGTRIO",
            "MEOWTH",
            "PERSIAN",
            "PSYDUCK",
            "GOLDUCK",
            "MANKEY",
            "PRIMEAPE",
            "GROWLITHE",
            "ARCANINE",
            "POLIWAG",
            "POLIWHIRL",
            "POLIWRATH",
            "ABRA",
            "KADABRA",
            "ALAKAZAM",
            "MACHOP",
            "MACHOKE",
            "MACHAMP",
            "BELLSPROUT",
            "WEEPINBELL",
            "VICTREEBEL",
            "TENTACOOL",
            "TENTACRUEL",
            "GEODUDE",
            "GRAVELER",
            "GOLEM",
            "PONYTA",
            "RAPIDASH",
            "SLOWPOKE",
            "SLOWBRO",
            "MAGNEMITE",
            "MAGNETON",
            "FARFETCHED",
            "DODUO",
            "DODRIO",
            "SEEL",
            "DEWGONG",
            "GRIMER",
            "MUK",
            "SHELLDER",
            "CLOYSTER",
            "GASTLY",
            "HAUNTER",
            "GENGAR",
            "ONIX",
            "DROWZEE",
            "HYPNO",
            "KRABBY",
            "KINGLER",
            "VOLTORB",
            "ELECTRODE",
            "EXEGGCUTE",
            "EXEGGUTOR",
            "CUBONE",
            "MAROWAK",
            "HITMONLEE",
            "HITMONCHAN",
            "LICKITUNG",
            "KOFFING",
            "WEEZING",
            "RHYHORN",
            "RHYDON",
            "CHANSEY",
            "TANGELA",
            "KANGASKHAN",
            "HORSEA",
            "SEADRA",
            "GOLDEEN",
            "SEAKING",
            "STARYU",
            "STARMIE",
            "MRMIME",
            "SCYTHER",
            "JYNX",
            "ELECTABUZZ",
            "MAGMAR",
            "PINSIR",
            "TAUROS",
            "MAGIKARP",
            "GYARADOS",
            "LAPRAS",
            "DITTO",
            "EEVEE",
            "VAPOREON",
            "JOLTEON",
            "FLAREON",
            "PORYGON",
            "OMANYTE",
            "OMASTAR",
            "KABUTO",
            "KABUTOPS",
            "AERODACTYL",
            "SNORLAX",
            "ARTICUNO",
            "ZAPDOS",
            "MOLTRES",
            "DRATINI",
            "DRAGONAIR",
            "DRAGONITE",
            "MEWTWO",
            "MEW",
            "CHIKORITA",
            "BAYLEEF",
            "MEGANIUM",
            "CYNDAQUIL",
            "QUILAVA",
            "TYPHLOSION",
            "TOTODILE",
            "CROCONAW",
            "FERALIGATR",
            "SENTRET",
            "FURRET",
            "HOOTHOOT",
            "NOCTOWL",
            "LEDYBA",
            "LEDIAN",
            "SPINARAK",
            "ARIADOS",
            "CROBAT",
            "CHINCHOU",
            "LANTURN",
            "PICHU",
            "CLEFFA",
            "IGGLYBUFF",
            "TOGEPI",
            "TOGETIC",
            "NATU",
            "XATU",
            "MAREEP",
            "FLAAFFY",
            "AMPHAROS",
            "BELLOSSOM",
            "MARILL",
            "AZUMARILL",
            "SUDOWOODO",
            "POLITOED",
            "HOPPIP",
            "SKIPLOOM",
            "JUMPLUFF",
            "AIPOM",
            "SUNKERN",
            "SUNFLORA",
            "YANMA",
            "WOOPER",
            "QUAGSIRE",
            "ESPEON",
            "UMBREON",
            "MURKROW",
            "SLOWKING",
            "MISDREAVUS",
            "UNOWN",
            "WOBBUFFET",
            "GIRAFARIG",
            "PINECO",
            "FORRETRESS",
            "DUNSPARCE",
            "GLIGAR",
            "STEELIX",
            "SNUBBULL",
            "GRANBULL",
            "QWILFISH",
            "SCIZOR",
            "SHUCKLE",
            "HERACROSS",
            "SNEASEL",
            "TEDDIURSA",
            "URSARING",
            "SLUGMA",
            "MAGCARGO",
            "SWINUB",
            "PILOSWINE",
            "CORSOLA",
            "REMORAID",
            "OCTILLERY",
            "DELIBIRD",
            "MANTINE",
            "SKARMORY",
            "HOUNDOUR",
            "HOUNDOOM",
            "KINGDRA",
            "PHANPY",
            "DONPHAN",
            "PORYGON",
            "STANTLER",
            "SMEARGLE",
            "TYROGUE",
            "HITMONTOP",
            "SMOOCHUM",
            "ELEKID",
            "MAGBY",
            "MILTANK",
            "BLISSEY",
            "RAIKOU",
            "ENTEI",
            "SUICUNE",
            "LARVITAR",
            "PUPITAR",
            "TYRANITAR",
            "LUGIA",
            "HOOH",
            "CELEBI",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "TREECKO",
            "GROVYLE",
            "SCEPTILE",
            "TORCHIC",
            "COMBUSKEN",
            "BLAZIKEN",
            "MUDKIP",
            "MARSHTOMP",
            "SWAMPERT",
            "POOCHYENA",
            "MIGHTYENA",
            "ZIGZAGOON",
            "LINOONE",
            "WURMPLE",
            "SILCOON",
            "BEAUTIFLY",
            "CASCOON",
            "DUSTOX",
            "LOTAD",
            "LOMBRE",
            "LUDICOLO",
            "SEEDOT",
            "NUZLEAF",
            "SHIFTRY",
            "NINCADA",
            "NINJASK",
            "SHEDINJA",
            "TAILLOW",
            "SWELLOW",
            "SHROOMISH",
            "BRELOOM",
            "SPINDA",
            "WINGULL",
            "PELIPPER",
            "SURSKIT",
            "MASQUERAIN",
            "WAILMER",
            "WAILORD",
            "SKITTY",
            "DELCATTY",
            "KECLEON",
            "BALTOY",
            "CLAYDOL",
            "NOSEPASS",
            "TORKOAL",
            "SABLEYE",
            "BARBOACH",
            "WHISCASH",
            "LUVDISC",
            "CORPHISH",
            "CRAWDAUNT",
            "FEEBAS",
            "MILOTIC",
            "CARVANHA",
            "SHARPEDO",
            "TRAPINCH",
            "VIBRAVA",
            "FLYGON",
            "MAKUHITA",
            "HARIYAMA",
            "ELECTRIKE",
            "MANECTRIC",
            "NUMEL",
            "CAMERUPT",
            "SPHEAL",
            "SEALEO",
            "WALREIN",
            "CACNEA",
            "CACTURNE",
            "SNORUNT",
            "GLALIE",
            "LUNATONE",
            "SOLROCK",
            "AZURILL",
            "SPOINK",
            "GRUMPIG",
            "PLUSLE",
            "MINUN",
            "MAWILE",
            "MEDITITE",
            "MEDICHAM",
            "SWABLU",
            "ALTARIA",
            "WYNAUT",
            "DUSKULL",
            "DUSCLOPS",
            "ROSELIA",
            "SLAKOTH",
            "VIGOROTH",
            "SLAKING",
            "GULPIN",
            "SWALOT",
            "TROPIUS",
            "WHISMUR",
            "LOUDRED",
            "EXPLOUD",
            "CLAMPERL",
            "HUNTAIL",
            "GOREBYSS",
            "ABSOL",
            "SHUPPET",
            "BANETTE",
            "SEVIPER",
            "ZANGOOSE",
            "RELICANTH",
            "ARON",
            "LAIRON",
            "AGGRON",
            "CASTFORM",
            "VOLBEAT",
            "ILLUMISE",
            "LILEEP",
            "CRADILY",
            "ANORITH",
            "ARMALDO",
            "RALTS",
            "KIRLIA",
            "GARDEVOIR",
            "BAGON",
            "SHELGON",
            "SALAMENCE",
            "BELDUM",
            "METANG",
            "METAGROSS",
            "REGIROCK",
            "REGICE",
            "REGISTEEL",
            "KYOGRE",
            "GROUDON",
            "RAYQUAZA",
            "LATIAS",
            "LATIOS",
            "JIRACHI",
            "DEOXYS",
            "CHIMECHO"});
            this.wildPokeName.Location = new System.Drawing.Point(54, 3);
            this.wildPokeName.Name = "wildPokeName";
            this.wildPokeName.Size = new System.Drawing.Size(100, 21);
            this.wildPokeName.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(160, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 21);
            this.label7.TabIndex = 10;
            this.label7.Text = "at level";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // wildPokeLevel
            // 
            this.wildPokeLevel.Location = new System.Drawing.Point(207, 3);
            this.wildPokeLevel.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.wildPokeLevel.Name = "wildPokeLevel";
            this.wildPokeLevel.Size = new System.Drawing.Size(40, 20);
            this.wildPokeLevel.TabIndex = 14;
            this.wildPokeLevel.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(3, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 21);
            this.label8.TabIndex = 11;
            this.label8.Text = "with a";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // wildPokeItem
            // 
            this.wildPokeItem.FormattingEnabled = true;
            this.wildPokeItem.Location = new System.Drawing.Point(44, 30);
            this.wildPokeItem.Name = "wildPokeItem";
            this.wildPokeItem.Size = new System.Drawing.Size(100, 21);
            this.wildPokeItem.TabIndex = 12;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel9);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(274, 119);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Give pokémon";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.flowLayoutPanel12, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.flowLayoutPanel2, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel9.TabIndex = 0;
            // 
            // flowLayoutPanel12
            // 
            this.flowLayoutPanel12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel12.AutoSize = true;
            this.flowLayoutPanel12.Controls.Add(this.btGivePoke);
            this.flowLayoutPanel12.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel12.Name = "flowLayoutPanel12";
            this.flowLayoutPanel12.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel12.TabIndex = 10;
            // 
            // btGivePoke
            // 
            this.btGivePoke.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btGivePoke.Location = new System.Drawing.Point(3, 3);
            this.btGivePoke.Name = "btGivePoke";
            this.btGivePoke.Size = new System.Drawing.Size(75, 23);
            this.btGivePoke.TabIndex = 13;
            this.btGivePoke.Text = "<< Insert";
            this.btGivePoke.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.label3);
            this.flowLayoutPanel2.Controls.Add(this.givePokeName);
            this.flowLayoutPanel2.Controls.Add(this.label4);
            this.flowLayoutPanel2.Controls.Add(this.givePokeLevel);
            this.flowLayoutPanel2.Controls.Add(this.label5);
            this.flowLayoutPanel2.Controls.Add(this.givePokeItem);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel2.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Give a";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // givePokeName
            // 
            this.givePokeName.FormattingEnabled = true;
            this.givePokeName.Items.AddRange(new object[] {
            "??????????",
            "BULBASAUR",
            "IVYSAUR",
            "VENUSAUR",
            "CHARMANDER",
            "CHARMELEON",
            "CHARIZARD",
            "SQUIRTLE",
            "WARTORTLE",
            "BLASTOISE",
            "CATERPIE",
            "METAPOD",
            "BUTTERFREE",
            "WEEDLE",
            "KAKUNA",
            "BEEDRILL",
            "PIDGEY",
            "PIDGEOTTO",
            "PIDGEOT",
            "RATTATA",
            "RATICATE",
            "SPEAROW",
            "FEAROW",
            "EKANS",
            "ARBOK",
            "PIKACHU",
            "RAICHU",
            "SANDSHREW",
            "SANDSLASH",
            "NIDORAN[F]",
            "NIDORINA",
            "NIDOQUEEN",
            "NIDORAN[M]",
            "NIDORINO",
            "NIDOKING",
            "CLEFAIRY",
            "CLEFABLE",
            "VULPIX",
            "NINETALES",
            "JIGGLYPUFF",
            "WIGGLYTUFF",
            "ZUBAT",
            "GOLBAT",
            "ODDISH",
            "GLOOM",
            "VILEPLUME",
            "PARAS",
            "PARASECT",
            "VENONAT",
            "VENOMOTH",
            "DIGLETT",
            "DUGTRIO",
            "MEOWTH",
            "PERSIAN",
            "PSYDUCK",
            "GOLDUCK",
            "MANKEY",
            "PRIMEAPE",
            "GROWLITHE",
            "ARCANINE",
            "POLIWAG",
            "POLIWHIRL",
            "POLIWRATH",
            "ABRA",
            "KADABRA",
            "ALAKAZAM",
            "MACHOP",
            "MACHOKE",
            "MACHAMP",
            "BELLSPROUT",
            "WEEPINBELL",
            "VICTREEBEL",
            "TENTACOOL",
            "TENTACRUEL",
            "GEODUDE",
            "GRAVELER",
            "GOLEM",
            "PONYTA",
            "RAPIDASH",
            "SLOWPOKE",
            "SLOWBRO",
            "MAGNEMITE",
            "MAGNETON",
            "FARFETCHED",
            "DODUO",
            "DODRIO",
            "SEEL",
            "DEWGONG",
            "GRIMER",
            "MUK",
            "SHELLDER",
            "CLOYSTER",
            "GASTLY",
            "HAUNTER",
            "GENGAR",
            "ONIX",
            "DROWZEE",
            "HYPNO",
            "KRABBY",
            "KINGLER",
            "VOLTORB",
            "ELECTRODE",
            "EXEGGCUTE",
            "EXEGGUTOR",
            "CUBONE",
            "MAROWAK",
            "HITMONLEE",
            "HITMONCHAN",
            "LICKITUNG",
            "KOFFING",
            "WEEZING",
            "RHYHORN",
            "RHYDON",
            "CHANSEY",
            "TANGELA",
            "KANGASKHAN",
            "HORSEA",
            "SEADRA",
            "GOLDEEN",
            "SEAKING",
            "STARYU",
            "STARMIE",
            "MRMIME",
            "SCYTHER",
            "JYNX",
            "ELECTABUZZ",
            "MAGMAR",
            "PINSIR",
            "TAUROS",
            "MAGIKARP",
            "GYARADOS",
            "LAPRAS",
            "DITTO",
            "EEVEE",
            "VAPOREON",
            "JOLTEON",
            "FLAREON",
            "PORYGON",
            "OMANYTE",
            "OMASTAR",
            "KABUTO",
            "KABUTOPS",
            "AERODACTYL",
            "SNORLAX",
            "ARTICUNO",
            "ZAPDOS",
            "MOLTRES",
            "DRATINI",
            "DRAGONAIR",
            "DRAGONITE",
            "MEWTWO",
            "MEW",
            "CHIKORITA",
            "BAYLEEF",
            "MEGANIUM",
            "CYNDAQUIL",
            "QUILAVA",
            "TYPHLOSION",
            "TOTODILE",
            "CROCONAW",
            "FERALIGATR",
            "SENTRET",
            "FURRET",
            "HOOTHOOT",
            "NOCTOWL",
            "LEDYBA",
            "LEDIAN",
            "SPINARAK",
            "ARIADOS",
            "CROBAT",
            "CHINCHOU",
            "LANTURN",
            "PICHU",
            "CLEFFA",
            "IGGLYBUFF",
            "TOGEPI",
            "TOGETIC",
            "NATU",
            "XATU",
            "MAREEP",
            "FLAAFFY",
            "AMPHAROS",
            "BELLOSSOM",
            "MARILL",
            "AZUMARILL",
            "SUDOWOODO",
            "POLITOED",
            "HOPPIP",
            "SKIPLOOM",
            "JUMPLUFF",
            "AIPOM",
            "SUNKERN",
            "SUNFLORA",
            "YANMA",
            "WOOPER",
            "QUAGSIRE",
            "ESPEON",
            "UMBREON",
            "MURKROW",
            "SLOWKING",
            "MISDREAVUS",
            "UNOWN",
            "WOBBUFFET",
            "GIRAFARIG",
            "PINECO",
            "FORRETRESS",
            "DUNSPARCE",
            "GLIGAR",
            "STEELIX",
            "SNUBBULL",
            "GRANBULL",
            "QWILFISH",
            "SCIZOR",
            "SHUCKLE",
            "HERACROSS",
            "SNEASEL",
            "TEDDIURSA",
            "URSARING",
            "SLUGMA",
            "MAGCARGO",
            "SWINUB",
            "PILOSWINE",
            "CORSOLA",
            "REMORAID",
            "OCTILLERY",
            "DELIBIRD",
            "MANTINE",
            "SKARMORY",
            "HOUNDOUR",
            "HOUNDOOM",
            "KINGDRA",
            "PHANPY",
            "DONPHAN",
            "PORYGON",
            "STANTLER",
            "SMEARGLE",
            "TYROGUE",
            "HITMONTOP",
            "SMOOCHUM",
            "ELEKID",
            "MAGBY",
            "MILTANK",
            "BLISSEY",
            "RAIKOU",
            "ENTEI",
            "SUICUNE",
            "LARVITAR",
            "PUPITAR",
            "TYRANITAR",
            "LUGIA",
            "HOOH",
            "CELEBI",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "?",
            "TREECKO",
            "GROVYLE",
            "SCEPTILE",
            "TORCHIC",
            "COMBUSKEN",
            "BLAZIKEN",
            "MUDKIP",
            "MARSHTOMP",
            "SWAMPERT",
            "POOCHYENA",
            "MIGHTYENA",
            "ZIGZAGOON",
            "LINOONE",
            "WURMPLE",
            "SILCOON",
            "BEAUTIFLY",
            "CASCOON",
            "DUSTOX",
            "LOTAD",
            "LOMBRE",
            "LUDICOLO",
            "SEEDOT",
            "NUZLEAF",
            "SHIFTRY",
            "NINCADA",
            "NINJASK",
            "SHEDINJA",
            "TAILLOW",
            "SWELLOW",
            "SHROOMISH",
            "BRELOOM",
            "SPINDA",
            "WINGULL",
            "PELIPPER",
            "SURSKIT",
            "MASQUERAIN",
            "WAILMER",
            "WAILORD",
            "SKITTY",
            "DELCATTY",
            "KECLEON",
            "BALTOY",
            "CLAYDOL",
            "NOSEPASS",
            "TORKOAL",
            "SABLEYE",
            "BARBOACH",
            "WHISCASH",
            "LUVDISC",
            "CORPHISH",
            "CRAWDAUNT",
            "FEEBAS",
            "MILOTIC",
            "CARVANHA",
            "SHARPEDO",
            "TRAPINCH",
            "VIBRAVA",
            "FLYGON",
            "MAKUHITA",
            "HARIYAMA",
            "ELECTRIKE",
            "MANECTRIC",
            "NUMEL",
            "CAMERUPT",
            "SPHEAL",
            "SEALEO",
            "WALREIN",
            "CACNEA",
            "CACTURNE",
            "SNORUNT",
            "GLALIE",
            "LUNATONE",
            "SOLROCK",
            "AZURILL",
            "SPOINK",
            "GRUMPIG",
            "PLUSLE",
            "MINUN",
            "MAWILE",
            "MEDITITE",
            "MEDICHAM",
            "SWABLU",
            "ALTARIA",
            "WYNAUT",
            "DUSKULL",
            "DUSCLOPS",
            "ROSELIA",
            "SLAKOTH",
            "VIGOROTH",
            "SLAKING",
            "GULPIN",
            "SWALOT",
            "TROPIUS",
            "WHISMUR",
            "LOUDRED",
            "EXPLOUD",
            "CLAMPERL",
            "HUNTAIL",
            "GOREBYSS",
            "ABSOL",
            "SHUPPET",
            "BANETTE",
            "SEVIPER",
            "ZANGOOSE",
            "RELICANTH",
            "ARON",
            "LAIRON",
            "AGGRON",
            "CASTFORM",
            "VOLBEAT",
            "ILLUMISE",
            "LILEEP",
            "CRADILY",
            "ANORITH",
            "ARMALDO",
            "RALTS",
            "KIRLIA",
            "GARDEVOIR",
            "BAGON",
            "SHELGON",
            "SALAMENCE",
            "BELDUM",
            "METANG",
            "METAGROSS",
            "REGIROCK",
            "REGICE",
            "REGISTEEL",
            "KYOGRE",
            "GROUDON",
            "RAYQUAZA",
            "LATIAS",
            "LATIOS",
            "JIRACHI",
            "DEOXYS",
            "CHIMECHO"});
            this.givePokeName.Location = new System.Drawing.Point(54, 3);
            this.givePokeName.Name = "givePokeName";
            this.givePokeName.Size = new System.Drawing.Size(100, 21);
            this.givePokeName.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(160, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 21);
            this.label4.TabIndex = 2;
            this.label4.Text = "at level";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // givePokeLevel
            // 
            this.givePokeLevel.Location = new System.Drawing.Point(207, 3);
            this.givePokeLevel.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.givePokeLevel.Name = "givePokeLevel";
            this.givePokeLevel.Size = new System.Drawing.Size(40, 20);
            this.givePokeLevel.TabIndex = 7;
            this.givePokeLevel.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(3, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "with a";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // givePokeItem
            // 
            this.givePokeItem.FormattingEnabled = true;
            this.givePokeItem.Location = new System.Drawing.Point(44, 30);
            this.givePokeItem.Name = "givePokeItem";
            this.givePokeItem.Size = new System.Drawing.Size(100, 21);
            this.givePokeItem.TabIndex = 5;
            // 
            // itemTab
            // 
            this.itemTab.Controls.Add(this.quickTable);
            this.itemTab.Location = new System.Drawing.Point(4, 22);
            this.itemTab.Name = "itemTab";
            this.itemTab.Size = new System.Drawing.Size(286, 532);
            this.itemTab.TabIndex = 0;
            this.itemTab.Text = "Items";
            this.itemTab.UseVisualStyleBackColor = true;
            // 
            // quickTable
            // 
            this.quickTable.ColumnCount = 1;
            this.quickTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.quickTable.Controls.Add(this.tableLayoutPanel10, 0, 0);
            this.quickTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.quickTable.Location = new System.Drawing.Point(0, 0);
            this.quickTable.Name = "quickTable";
            this.quickTable.RowCount = 1;
            this.quickTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.quickTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 532F));
            this.quickTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 532F));
            this.quickTable.Size = new System.Drawing.Size(286, 532);
            this.quickTable.TabIndex = 1;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.groupBox8, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.groupBox3, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.groupBox7, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 4;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 125F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(280, 526);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.tableLayoutPanel12);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox8.Location = new System.Drawing.Point(3, 253);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(274, 119);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Check item";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.flowLayoutPanel15, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.flowLayoutPanel3, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // flowLayoutPanel15
            // 
            this.flowLayoutPanel15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel15.AutoSize = true;
            this.flowLayoutPanel15.Controls.Add(this.button8);
            this.flowLayoutPanel15.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel15.Name = "flowLayoutPanel15";
            this.flowLayoutPanel15.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel15.TabIndex = 11;
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button8.Location = new System.Drawing.Point(3, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 13;
            this.button8.Text = "<< Insert";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.label19);
            this.flowLayoutPanel3.Controls.Add(this.numericUpDown3);
            this.flowLayoutPanel3.Controls.Add(this.label20);
            this.flowLayoutPanel3.Controls.Add(this.comboBox6);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel3.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 13);
            this.label19.TabIndex = 14;
            this.label19.Text = "Check";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(47, 3);
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(40, 20);
            this.numericUpDown3.TabIndex = 15;
            this.numericUpDown3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(93, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "units of";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(140, 3);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(100, 21);
            this.comboBox6.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.itemTable);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(274, 119);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Give item";
            // 
            // itemTable
            // 
            this.itemTable.ColumnCount = 1;
            this.itemTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.itemTable.Controls.Add(this.flowLayoutPanel13, 0, 1);
            this.itemTable.Controls.Add(this.flowLayoutPanel4, 0, 0);
            this.itemTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemTable.Location = new System.Drawing.Point(3, 16);
            this.itemTable.Name = "itemTable";
            this.itemTable.RowCount = 2;
            this.itemTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.itemTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.itemTable.Size = new System.Drawing.Size(268, 100);
            this.itemTable.TabIndex = 0;
            // 
            // flowLayoutPanel13
            // 
            this.flowLayoutPanel13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel13.AutoSize = true;
            this.flowLayoutPanel13.Controls.Add(this.button6);
            this.flowLayoutPanel13.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel13.Name = "flowLayoutPanel13";
            this.flowLayoutPanel13.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel13.TabIndex = 11;
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button6.Location = new System.Drawing.Point(3, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 13;
            this.button6.Text = "<< Insert";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.label9);
            this.flowLayoutPanel4.Controls.Add(this.numericUpDown1);
            this.flowLayoutPanel4.Controls.Add(this.label10);
            this.flowLayoutPanel4.Controls.Add(this.comboBox1);
            this.flowLayoutPanel4.Controls.Add(this.radioButton1);
            this.flowLayoutPanel4.Controls.Add(this.radioButton2);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel4.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Give";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(38, 3);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(40, 20);
            this.numericUpDown1.TabIndex = 8;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(84, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "units of";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(131, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 13;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(3, 30);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(53, 17);
            this.radioButton1.TabIndex = 14;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Given";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(62, 30);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(55, 17);
            this.radioButton2.TabIndex = 15;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Found";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tableLayoutPanel11);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(3, 128);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(274, 119);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Remove item";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.flowLayoutPanel14, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.flowLayoutPanel5, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(268, 100);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // flowLayoutPanel14
            // 
            this.flowLayoutPanel14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel14.AutoSize = true;
            this.flowLayoutPanel14.Controls.Add(this.button7);
            this.flowLayoutPanel14.Location = new System.Drawing.Point(93, 65);
            this.flowLayoutPanel14.Name = "flowLayoutPanel14";
            this.flowLayoutPanel14.Size = new System.Drawing.Size(81, 29);
            this.flowLayoutPanel14.TabIndex = 11;
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button7.Location = new System.Drawing.Point(3, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "<< Insert";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this.label11);
            this.flowLayoutPanel5.Controls.Add(this.numericUpDown2);
            this.flowLayoutPanel5.Controls.Add(this.label12);
            this.flowLayoutPanel5.Controls.Add(this.comboBox2);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(262, 54);
            this.flowLayoutPanel5.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Remove";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(56, 3);
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(40, 20);
            this.numericUpDown2.TabIndex = 15;
            this.numericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(102, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 16;
            this.label12.Text = "units of";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(149, 3);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 21);
            this.comboBox2.TabIndex = 17;
            // 
            // soundTab
            // 
            this.soundTab.Controls.Add(this.tableLayoutPanel5);
            this.soundTab.Location = new System.Drawing.Point(4, 22);
            this.soundTab.Name = "soundTab";
            this.soundTab.Padding = new System.Windows.Forms.Padding(3);
            this.soundTab.Size = new System.Drawing.Size(286, 532);
            this.soundTab.TabIndex = 2;
            this.soundTab.Text = "Sounds";
            this.soundTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.groupBox4, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(280, 526);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel7);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(274, 257);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Sounds";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.flowLayoutPanel7, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.flowLayoutPanel6, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(268, 238);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.Controls.Add(this.label14);
            this.flowLayoutPanel7.Controls.Add(this.comboBox4);
            this.flowLayoutPanel7.Controls.Add(this.checkBox2);
            this.flowLayoutPanel7.Controls.Add(this.button4);
            this.flowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel7.Location = new System.Drawing.Point(4, 122);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Size = new System.Drawing.Size(260, 112);
            this.flowLayoutPanel7.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Play this cry:";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(75, 3);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(120, 21);
            this.comboBox4.TabIndex = 13;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(3, 30);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(139, 17);
            this.checkBox2.TabIndex = 17;
            this.checkBox2.Text = "Stop script while playing";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(148, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 16;
            this.button4.Text = "<< Insert";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this.label13);
            this.flowLayoutPanel6.Controls.Add(this.comboBox3);
            this.flowLayoutPanel6.Controls.Add(this.checkBox1);
            this.flowLayoutPanel6.Controls.Add(this.button3);
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(4, 4);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(260, 111);
            this.flowLayoutPanel6.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Play this fanfare:";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(94, 3);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(120, 21);
            this.comboBox3.TabIndex = 13;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(3, 30);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(139, 17);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "Stop script while playing";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(148, 30);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 16;
            this.button3.Text = "<< Insert";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(793, 558);
            this.splitContainer1.SplitterDistance = 264;
            this.splitContainer1.TabIndex = 1;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(793, 264);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.scriptBox);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(785, 238);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Script";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // scriptBox
            // 
            this.scriptBox.AcceptsReturn = true;
            this.scriptBox.AcceptsTab = true;
            this.scriptBox.AllowDrop = true;
            this.scriptBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scriptBox.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scriptBox.Location = new System.Drawing.Point(3, 3);
            this.scriptBox.Multiline = true;
            this.scriptBox.Name = "scriptBox";
            this.scriptBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.scriptBox.Size = new System.Drawing.Size(779, 232);
            this.scriptBox.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(793, 290);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.stringBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(785, 264);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Text strings";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // stringBox
            // 
            this.stringBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stringBox.FormattingEnabled = true;
            this.stringBox.HorizontalScrollbar = true;
            this.stringBox.IntegralHeight = false;
            this.stringBox.Location = new System.Drawing.Point(3, 3);
            this.stringBox.Name = "stringBox";
            this.stringBox.ScrollAlwaysVisible = true;
            this.stringBox.Size = new System.Drawing.Size(779, 258);
            this.stringBox.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(785, 264);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Movements";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(785, 264);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Other RAWs";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(280, 501);
            // 
            // nuevoToolStripButton
            // 
            this.nuevoToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.nuevoToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("nuevoToolStripButton.Image")));
            this.nuevoToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.nuevoToolStripButton.Name = "nuevoToolStripButton";
            this.nuevoToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.nuevoToolStripButton.Text = "&Nuevo";
            // 
            // abrirToolStripButton
            // 
            this.abrirToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.abrirToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("abrirToolStripButton.Image")));
            this.abrirToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.abrirToolStripButton.Name = "abrirToolStripButton";
            this.abrirToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.abrirToolStripButton.Text = "&Abrir";
            // 
            // guardarToolStripButton
            // 
            this.guardarToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.guardarToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("guardarToolStripButton.Image")));
            this.guardarToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.guardarToolStripButton.Name = "guardarToolStripButton";
            this.guardarToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.guardarToolStripButton.Text = "&Guardar";
            // 
            // cortarToolStripButton
            // 
            this.cortarToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cortarToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cortarToolStripButton.Image")));
            this.cortarToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cortarToolStripButton.Name = "cortarToolStripButton";
            this.cortarToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cortarToolStripButton.Text = "Cort&ar";
            // 
            // copiarToolStripButton
            // 
            this.copiarToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copiarToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copiarToolStripButton.Image")));
            this.copiarToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copiarToolStripButton.Name = "copiarToolStripButton";
            this.copiarToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copiarToolStripButton.Text = "&Copiar";
            // 
            // pegarToolStripButton
            // 
            this.pegarToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pegarToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pegarToolStripButton.Image")));
            this.pegarToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pegarToolStripButton.Name = "pegarToolStripButton";
            this.pegarToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.pegarToolStripButton.Text = "&Pegar";
            // 
            // movBt
            // 
            this.movBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.movBt.Image = global::ScriptEd.Properties.Resources.fr_move_mini;
            this.movBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.movBt.Name = "movBt";
            this.movBt.Size = new System.Drawing.Size(23, 22);
            this.movBt.Text = "Apply movement";
            this.movBt.Click += new System.EventHandler(this.movBt_Click);
            // 
            // martBt
            // 
            this.martBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.martBt.Image = global::ScriptEd.Properties.Resources.mart_ico;
            this.martBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.martBt.Name = "martBt";
            this.martBt.Size = new System.Drawing.Size(23, 22);
            this.martBt.Text = "Add a Pokemart";
            this.martBt.Click += new System.EventHandler(this.OpenAddMart);
            // 
            // addStrBt
            // 
            this.addStrBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.addStrBt.Image = global::ScriptEd.Properties.Resources.srtings;
            this.addStrBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.addStrBt.Name = "addStrBt";
            this.addStrBt.Size = new System.Drawing.Size(23, 22);
            this.addStrBt.Text = "Add String";
            this.addStrBt.Click += new System.EventHandler(this.openAddStr);
            // 
            // closeKeypressBt
            // 
            this.closeKeypressBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.closeKeypressBt.Enabled = false;
            this.closeKeypressBt.Image = global::ScriptEd.Properties.Resources.close_keypress;
            this.closeKeypressBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(192)))), ((int)(((byte)(160)))));
            this.closeKeypressBt.Name = "closeKeypressBt";
            this.closeKeypressBt.Size = new System.Drawing.Size(23, 22);
            this.closeKeypressBt.Text = "Close on key press";
            // 
            // newScriptBt
            // 
            this.newScriptBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newScriptBt.Image = global::ScriptEd.Properties.Resources.newScript;
            this.newScriptBt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newScriptBt.Name = "newScriptBt";
            this.newScriptBt.Size = new System.Drawing.Size(23, 22);
            this.newScriptBt.Text = "New script";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lockToolStripMenuItem,
            this.lockAllToolStripMenuItem,
            this.releaseToolStripMenuItem,
            this.releaseAllToolStripMenuItem});
            this.toolStripButton1.Image = global::ScriptEd.Properties.Resources._lock;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripButton1.Text = "Lock / release";
            // 
            // lockToolStripMenuItem
            // 
            this.lockToolStripMenuItem.Name = "lockToolStripMenuItem";
            this.lockToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.lockToolStripMenuItem.Text = "Lock";
            // 
            // lockAllToolStripMenuItem
            // 
            this.lockAllToolStripMenuItem.Name = "lockAllToolStripMenuItem";
            this.lockAllToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.lockAllToolStripMenuItem.Text = "Lock all";
            // 
            // releaseToolStripMenuItem
            // 
            this.releaseToolStripMenuItem.Name = "releaseToolStripMenuItem";
            this.releaseToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.releaseToolStripMenuItem.Text = "Release";
            // 
            // releaseAllToolStripMenuItem
            // 
            this.releaseAllToolStripMenuItem.Name = "releaseAllToolStripMenuItem";
            this.releaseAllToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.releaseAllToolStripMenuItem.Text = "Release all";
            // 
            // faceplayerBt
            // 
            this.faceplayerBt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.faceplayerBt.Image = global::ScriptEd.Properties.Resources.faceplayer;
            this.faceplayerBt.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(197)))), ((int)(((byte)(165)))));
            this.faceplayerBt.Name = "faceplayerBt";
            this.faceplayerBt.Size = new System.Drawing.Size(23, 22);
            this.faceplayerBt.Text = "Face player";
            // 
            // ayudaToolStripButton
            // 
            this.ayudaToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ayudaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ayudaToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("ayudaToolStripButton.Image")));
            this.ayudaToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ayudaToolStripButton.Name = "ayudaToolStripButton";
            this.ayudaToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.ayudaToolStripButton.Text = "Ay&uda";
            // 
            // mainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1099, 613);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Glitched Script Editor";
            this.Shown += new System.EventHandler(this.openFirst);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.calcTab.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.pokeTab.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.flowLayoutPanel16.ResumeLayout(false);
            this.flowLayoutPanel17.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.flowLayoutPanel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pokepicX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pokepicY)).EndInit();
            this.flowLayoutPanel10.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.flowLayoutPanel11.ResumeLayout(false);
            this.flowLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.wildPokeLevel)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.flowLayoutPanel12.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.givePokeLevel)).EndInit();
            this.itemTab.ResumeLayout(false);
            this.quickTable.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.flowLayoutPanel15.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.itemTable.ResumeLayout(false);
            this.itemTable.PerformLayout();
            this.flowLayoutPanel13.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.flowLayoutPanel14.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.soundTab.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.flowLayoutPanel7.ResumeLayout(false);
            this.flowLayoutPanel7.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ToolStripLabel romTypeText;
        private System.Windows.Forms.TextBox scriptBox;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage calcTab;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cortarToolStripButton;
        private System.Windows.Forms.ToolStripButton copiarToolStripButton;
        private System.Windows.Forms.ToolStripButton pegarToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton ayudaToolStripButton;
        private System.Windows.Forms.TabPage pokeTab;
        private System.Windows.Forms.TabPage itemTab;
        private System.Windows.Forms.TableLayoutPanel quickTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DTH;
        private System.Windows.Forms.Button copyDec_bt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button decToHex_bt;
        private System.Windows.Forms.Button hexToDec_bt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox HTD;
        private System.Windows.Forms.Button copyHex_bt;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.TabPage soundTab;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox picPokeName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown pokepicX;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown pokepicY;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel10;
        private System.Windows.Forms.Button btPokePic;
        private System.Windows.Forms.Button btPrevPic;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel11;
        private System.Windows.Forms.Button btWildPoke;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox wildPokeName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown wildPokeLevel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox wildPokeItem;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel12;
        private System.Windows.Forms.Button btGivePoke;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox givePokeName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown givePokeLevel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox givePokeItem;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel16;
        private System.Windows.Forms.Button btGiveEgg;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox eggPokeName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel itemTable;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel13;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel14;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ToolStripButton movBt;
        private System.Windows.Forms.ToolStripButton nuevoToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton martBt;
        private System.Windows.Forms.ToolStripButton abrirToolStripButton;
        private System.Windows.Forms.ToolStripButton guardarToolStripButton;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel15;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ToolStripButton addStrBt;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton newScriptBt;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem lockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lockAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton faceplayerBt;
        private System.Windows.Forms.ToolStripMenuItem releaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem releaseAllToolStripMenuItem;
        public System.Windows.Forms.ListBox stringBox;
        private System.Windows.Forms.ToolStripButton closeKeypressBt;
    }
}

